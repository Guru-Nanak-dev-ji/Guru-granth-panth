# MANIFEST — Phase 10.2.1

| Path | Purpose |
|---|---|
| README.md | Scope, deny-by-default boot seal, run instructions, candidate status |
| PHASE-10-EXIT-GATE.md | Freeze gate; independent post-patch Grok PASS still required |
| PHASE-10.2.1-BOOT-SEAL.md | Phase 10.2 second-pass M1/M2 closure |
| PHASE-10.2-HARDENING.md | Phase 10.1 red-team findings closed in 10.2 |
| ARCHIVE-PHASE-10.1-HARDENING.md | Superseded 10.1 verification record; audit history only |
| GROK-10.1-REDTEAM-SUMMARY.md | Summary of independent 10.1 FAIL findings |
| GROK-10.2-SECOND-PASS-SUMMARY.md | Summary of independent 10.2 FAIL findings |
| GROK-RED-TEAM-HANDOFF.md | Independent Phase 10.2.1 post-patch attack brief |
| SECURITY-NOTES.md | Trust boundary, auth, money, recon, sealed surface |
| WEBHOOKS.md | Authenticated actor + HMAC/replay rules |
| RBAC-MATRIX.md | Role/permission matrix |
| STATE-MACHINE.md | State transitions |
| TEST-MATRIX.md | Test mapping |
| config/sandbox.json | Sealed sandbox config |
| openapi/v1.yaml | 10.2.1 reference adapter contract |
| migrations/001_sandbox_core.sql | PostgreSQL reference schema |
| src/bfn_sandbox/ | Runnable SQLite sandbox engine |
| tests/test_hardening_10_1.py | Prior 10.1 regression guards |
| tests/test_redteam_10_2.py | 10.2 + 10.2.1 red-team regression guards |
| LICENSE-SANDBOX.txt | Sandbox-only notice |
