> SUPERSEDED by Phase 10.2 after independent red-team FAIL. Retained only for audit history.

# Phase 10.1 Hardening Report

This patch closes the security gaps found during review of the Phase 10 Frozen Sandbox Core. It does **not** enable live money or start Phase 11.

## Closed findings

1. **Webhook replay-key poisoning** — fixed by verifying HMAC/skew before any durable replay reservation.
2. **Cross-merchant object authorization** — merchant intent, QR, invoice, payout request, payout approval (merchant roles), authorization and pending-settlement mutations now require ACTIVE membership on the exact merchant.
3. **Unauthorized merchant creation** — only a stored ACTIVE user with role `owner` can create a merchant.
4. **Webhook validation failures** — missing IDs, unknown event types, unknown intents, non-object/malformed JSON and malformed signature timestamps return controlled domain errors rather than raw `KeyError`, `ValueError`, or SQLite errors.
5. **Webhook event-id collision** — same verified event id with different payload returns `409 Conflict`.
6. **Actor role forgery on hardened paths** — caller role must match the stored ACTIVE user record.
7. **Creation idempotency contract** — merchants, QR, payment intents, invoices and payouts now enforce `Idempotency-Key` consistently with OpenAPI.
8. **Compliance checker contract** — `platform_compliance` can perform the documented independent payout approval while maker ≠ checker remains enforced.

## Verification commands

```bash
PYTHONPATH=src python3 -m pytest tests -q
python3 -m compileall -q src
PYTHONPATH=src python3 -m bfn_sandbox.boot config/sandbox.json
```

The packaged artifact is acceptable only if all commands pass and every sealed execution flag remains false.

## Packaging verification

The release ZIP is verified from a fresh unzip. Expected current suite result: **61 passed**.
