# PHASE-10.2.1 EXIT GATE

Phase 10.2.1 may be called frozen only after all local checks are green **and** an independent post-patch red-team accepts it.

- [x] Sealed config flags are deny-by-default and accept only explicit false spellings
- [x] Every sealed environment override is deny-by-default when present
- [x] Unknown/truthy `LIVE_MONEY_ENABLED` environment spellings refuse boot
- [x] Production-class credentials fail boot, including nested config/list values
- [x] Environment is local|sandbox only
- [x] Strict CAD integer minor units; bool/float/string rejected
- [x] Payment intents require merchant_id and exact ACTIVE merchant membership
- [x] Expected malformed input returns controlled BFN errors, not raw KeyError/ValueError/SQLite errors
- [x] Idempotency-Key is a non-empty string
- [x] Authorize/post and pending-settlement helpers enforce explicit RBAC
- [x] Public user creation cannot mint privileged platform/system/partner roles
- [x] `system` has no merchant-membership bypass
- [x] Webhook requires stored ingest actor + HMAC; signature verified before replay reservation
- [x] Duplicate timestamp fields in webhook signature are rejected
- [x] Same verified external_event_id + different payload = 409
- [x] Reconciliation BREAK freezes initiation, payouts, and partner rail
- [x] Manual invoice transition requires actor, permission, and merchant membership
- [x] Donation campaign and money execution remain NOT_OFFERED
- [x] OpenAPI removes uncompiled refund/dispute/cancel/donation operations and dead RefundRequest schema
- [x] SQLite role constraint mirrors PostgreSQL role allowlist
- [x] Database feature flags are constrained to false
- [x] SETTLED still requires verified mock-partner flow
- [x] Maker cannot approve own payout
- [x] Phase 11 not compiled/opened
- [x] Independent Phase 10.2 second-pass findings M1/M2 reproduced and patched
- [ ] Independent Phase 10.2.1 post-patch red-team returns PASS
- [ ] Legal/regulatory classification completed (not claimed)

Still forbidden: live credentials, production deploy/DNS, cards, FX, remittance, KDN production writes, public bank claim, Phase 11.
