"""SQLite runtime schema mirroring migrations/001_sandbox_core.sql invariants."""

from __future__ import annotations

import sqlite3

SCHEMA = """
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
  user_id TEXT PRIMARY KEY CHECK (user_id LIKE 'sbx_%'),
  environment TEXT NOT NULL CHECK (environment IN ('local','sandbox')),
  handle TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN (
    'customer','cashier','finance','owner','support','analyst',
    'platform_support','platform_compliance','platform_admin','partner_tech','system','ai_assistant'
  )),
  status TEXT NOT NULL CHECK (status IN ('ACTIVE','DISABLED')),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (environment, handle)
);

CREATE TABLE IF NOT EXISTS merchants (
  merchant_id TEXT PRIMARY KEY CHECK (merchant_id LIKE 'sbx_%'),
  environment TEXT NOT NULL CHECK (environment IN ('local','sandbox')),
  display_name TEXT NOT NULL,
  legal_name TEXT,
  status TEXT NOT NULL CHECK (status IN (
    'DRAFT','ONBOARDING','REVIEW_REQUIRED','SANDBOX_ACTIVE','LIMITED','SUSPENDED','CLOSED'
  )),
  risk_tier TEXT NOT NULL CHECK (risk_tier IN ('S0','L1','L2','L3','R')),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS merchant_members (
  merchant_id TEXT NOT NULL REFERENCES merchants(merchant_id),
  user_id TEXT NOT NULL REFERENCES users(user_id),
  role TEXT NOT NULL CHECK (role IN ('owner','finance','cashier','support','analyst')),
  status TEXT NOT NULL CHECK (status IN ('ACTIVE','REVOKED')),
  PRIMARY KEY (merchant_id, user_id)
);

CREATE TABLE IF NOT EXISTS accounts (
  account_id TEXT PRIMARY KEY CHECK (account_id LIKE 'sbx_%'),
  environment TEXT NOT NULL CHECK (environment IN ('local','sandbox')),
  currency TEXT NOT NULL CHECK (currency = 'CAD'),
  book TEXT NOT NULL CHECK (book IN ('SANDBOX_CASH','SANDBOX_POINTS')),
  owner_type TEXT NOT NULL,
  owner_id TEXT,
  purpose TEXT NOT NULL CHECK (purpose IN (
    'operating','safeguarded_subledger','customer_wallet','merchant_receivable',
    'payable','fee','donation_restricted','hold','fx_clearing'
  ))
);

CREATE TABLE IF NOT EXISTS ledger_journals (
  journal_id TEXT PRIMARY KEY CHECK (journal_id LIKE 'sbx_%'),
  environment TEXT NOT NULL CHECK (environment IN ('local','sandbox')),
  source_type TEXT NOT NULL,
  source_id TEXT NOT NULL,
  sealed INTEGER NOT NULL DEFAULT 0,
  reverses_journal_id TEXT REFERENCES ledger_journals(journal_id),
  created_by TEXT NOT NULL REFERENCES users(user_id),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (environment, source_type, source_id)
);

CREATE TABLE IF NOT EXISTS ledger_entries (
  entry_id TEXT PRIMARY KEY CHECK (entry_id LIKE 'sbx_%'),
  journal_id TEXT NOT NULL REFERENCES ledger_journals(journal_id),
  account_id TEXT NOT NULL REFERENCES accounts(account_id),
  currency TEXT NOT NULL CHECK (currency = 'CAD'),
  debit_minor INTEGER NOT NULL DEFAULT 0 CHECK (debit_minor >= 0),
  credit_minor INTEGER NOT NULL DEFAULT 0 CHECK (credit_minor >= 0),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CHECK (
    (debit_minor > 0 AND credit_minor = 0) OR
    (debit_minor = 0 AND credit_minor > 0)
  )
);

CREATE TRIGGER IF NOT EXISTS trg_entries_no_update
BEFORE UPDATE ON ledger_entries
BEGIN
  SELECT CASE WHEN (SELECT sealed FROM ledger_journals WHERE journal_id = OLD.journal_id) = 1
    THEN RAISE(ABORT, 'posted ledger entries are immutable; create a reversal journal')
  END;
END;

CREATE TRIGGER IF NOT EXISTS trg_entries_no_delete
BEFORE DELETE ON ledger_entries
BEGIN
  SELECT CASE WHEN (SELECT sealed FROM ledger_journals WHERE journal_id = OLD.journal_id) = 1
    THEN RAISE(ABORT, 'posted ledger entries are immutable; create a reversal journal')
  END;
END;

CREATE TRIGGER IF NOT EXISTS trg_journals_no_delete
BEFORE DELETE ON ledger_journals
BEGIN
  SELECT RAISE(ABORT, 'journals cannot be deleted');
END;

CREATE TRIGGER IF NOT EXISTS trg_journals_seal
BEFORE UPDATE ON ledger_journals
BEGIN
  SELECT CASE
    WHEN OLD.sealed = 1 AND NEW.sealed = 0
      THEN RAISE(ABORT, 'sealed journals cannot be unsealed')
    WHEN NEW.sealed = 1 AND OLD.sealed = 0 AND (
      SELECT COALESCE(SUM(debit_minor),0) FROM ledger_entries WHERE journal_id = NEW.journal_id
    ) != (
      SELECT COALESCE(SUM(credit_minor),0) FROM ledger_entries WHERE journal_id = NEW.journal_id
    )
      THEN RAISE(ABORT, 'journal debit total must equal credit total')
  END;
END;

CREATE TABLE IF NOT EXISTS idempotency_keys (
  environment TEXT NOT NULL,
  principal_id TEXT NOT NULL,
  route TEXT NOT NULL,
  idempotency_key TEXT NOT NULL,
  body_hash TEXT NOT NULL,
  resource_type TEXT,
  resource_id TEXT,
  status_code INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (environment, principal_id, route, idempotency_key)
);

CREATE TABLE IF NOT EXISTS partner_events (
  partner_event_id TEXT PRIMARY KEY CHECK (partner_event_id LIKE 'sbx_%'),
  environment TEXT NOT NULL,
  partner_source TEXT NOT NULL CHECK (partner_source = 'mock_partner'),
  external_event_id TEXT NOT NULL,
  event_type TEXT NOT NULL,
  payment_intent_id TEXT,
  payload_hash TEXT NOT NULL,
  verified INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (environment, partner_source, external_event_id)
);

CREATE TABLE IF NOT EXISTS webhook_receipts (
  receipt_id TEXT PRIMARY KEY CHECK (receipt_id LIKE 'sbx_%'),
  environment TEXT NOT NULL,
  partner_source TEXT NOT NULL,
  external_event_id TEXT NOT NULL,
  timestamp_unix INTEGER NOT NULL,
  verified INTEGER NOT NULL,
  disposition TEXT NOT NULL,
  raw_body_sha256 TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE (environment, partner_source, external_event_id)
);

CREATE TABLE IF NOT EXISTS webhook_dlq (
  dlq_id TEXT PRIMARY KEY,
  receipt_id TEXT,
  reason TEXT NOT NULL,
  retry_count INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS approvals (
  approval_id TEXT PRIMARY KEY CHECK (approval_id LIKE 'sbx_%'),
  environment TEXT NOT NULL,
  resource_type TEXT NOT NULL,
  resource_id TEXT NOT NULL,
  action TEXT NOT NULL,
  requested_by TEXT NOT NULL REFERENCES users(user_id),
  approved_by TEXT REFERENCES users(user_id),
  status TEXT NOT NULL CHECK (status IN ('PENDING','APPROVED','REJECTED')),
  reason TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CHECK (approved_by IS NULL OR approved_by <> requested_by)
);

CREATE TABLE IF NOT EXISTS audit_events (
  audit_id TEXT PRIMARY KEY CHECK (audit_id LIKE 'sbx_%'),
  environment TEXT NOT NULL,
  actor_id TEXT,
  actor_role TEXT,
  action TEXT NOT NULL,
  resource_type TEXT,
  resource_id TEXT,
  before_state TEXT,
  after_state TEXT,
  reason_code TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS kill_switches (
  code TEXT PRIMARY KEY,
  environment TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 0,
  reason TEXT,
  activated_by TEXT
);

CREATE TABLE IF NOT EXISTS payment_intents (
  payment_intent_id TEXT PRIMARY KEY CHECK (payment_intent_id LIKE 'sbx_%'),
  environment TEXT NOT NULL CHECK (environment IN ('local','sandbox')),
  merchant_id TEXT REFERENCES merchants(merchant_id),
  payer_id TEXT REFERENCES users(user_id),
  amount_minor INTEGER NOT NULL CHECK (amount_minor > 0),
  currency TEXT NOT NULL CHECK (currency = 'CAD'),
  intent_status TEXT NOT NULL,
  settlement_status TEXT NOT NULL,
  exception_status TEXT NOT NULL,
  purpose TEXT NOT NULL,
  invoice_id TEXT,
  order_id TEXT,
  expires_at TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS qr_tokens (
  qr_token_id TEXT PRIMARY KEY CHECK (qr_token_id LIKE 'sbx_%'),
  environment TEXT NOT NULL,
  qr_kind TEXT NOT NULL CHECK (qr_kind IN ('STATIC','DYNAMIC')),
  merchant_id TEXT NOT NULL REFERENCES merchants(merchant_id),
  payment_intent_id TEXT REFERENCES payment_intents(payment_intent_id),
  nonce TEXT NOT NULL,
  payload_hmac TEXT NOT NULL,
  amount_minor INTEGER,
  consumed INTEGER NOT NULL DEFAULT 0,
  expires_at INTEGER,
  UNIQUE (environment, nonce)
);

CREATE TABLE IF NOT EXISTS invoices (
  invoice_id TEXT PRIMARY KEY CHECK (invoice_id LIKE 'sbx_%'),
  environment TEXT NOT NULL,
  merchant_id TEXT NOT NULL REFERENCES merchants(merchant_id),
  buyer_id TEXT,
  status TEXT NOT NULL,
  currency TEXT NOT NULL CHECK (currency = 'CAD'),
  total_minor INTEGER NOT NULL CHECK (total_minor > 0),
  paid_minor INTEGER NOT NULL DEFAULT 0 CHECK (paid_minor >= 0),
  refunded_minor INTEGER NOT NULL DEFAULT 0 CHECK (refunded_minor >= 0),
  CHECK (paid_minor <= total_minor),
  CHECK (refunded_minor <= paid_minor)
);

CREATE TABLE IF NOT EXISTS invoice_line_items (
  line_id TEXT PRIMARY KEY CHECK (line_id LIKE 'sbx_%'),
  invoice_id TEXT NOT NULL REFERENCES invoices(invoice_id),
  description TEXT NOT NULL,
  quantity INTEGER NOT NULL CHECK (quantity > 0),
  unit_minor INTEGER NOT NULL CHECK (unit_minor >= 0),
  tax_minor INTEGER NOT NULL DEFAULT 0,
  discount_minor INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS payables (
  payable_id TEXT PRIMARY KEY CHECK (payable_id LIKE 'sbx_%'),
  environment TEXT NOT NULL,
  source_type TEXT NOT NULL,
  source_id TEXT NOT NULL,
  merchant_id TEXT,
  beneficiary_id TEXT NOT NULL,
  currency TEXT NOT NULL CHECK (currency = 'CAD'),
  eligible_minor INTEGER NOT NULL CHECK (eligible_minor >= 0),
  reserved_minor INTEGER NOT NULL DEFAULT 0,
  paid_minor INTEGER NOT NULL DEFAULT 0,
  source_settled INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS payouts (
  payout_id TEXT PRIMARY KEY CHECK (payout_id LIKE 'sbx_%'),
  environment TEXT NOT NULL,
  payable_id TEXT NOT NULL REFERENCES payables(payable_id),
  amount_minor INTEGER NOT NULL CHECK (amount_minor > 0),
  currency TEXT NOT NULL CHECK (currency = 'CAD'),
  destination_token_ref TEXT NOT NULL,
  status TEXT NOT NULL,
  requested_by TEXT NOT NULL REFERENCES users(user_id),
  approved_by TEXT,
  partner_event_id TEXT,
  reconciliation_key TEXT NOT NULL,
  UNIQUE (environment, reconciliation_key),
  CHECK (approved_by IS NULL OR approved_by <> requested_by)
);

CREATE TABLE IF NOT EXISTS refunds (
  refund_id TEXT PRIMARY KEY CHECK (refund_id LIKE 'sbx_%'),
  environment TEXT NOT NULL,
  payment_intent_id TEXT NOT NULL REFERENCES payment_intents(payment_intent_id),
  amount_minor INTEGER NOT NULL CHECK (amount_minor > 0),
  currency TEXT NOT NULL CHECK (currency = 'CAD'),
  status TEXT NOT NULL,
  reason TEXT,
  created_by TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS disputes (
  dispute_id TEXT PRIMARY KEY CHECK (dispute_id LIKE 'sbx_%'),
  environment TEXT NOT NULL,
  payment_intent_id TEXT NOT NULL REFERENCES payment_intents(payment_intent_id),
  amount_minor INTEGER NOT NULL,
  currency TEXT NOT NULL CHECK (currency = 'CAD'),
  status TEXT NOT NULL,
  reason_code TEXT
);

CREATE TABLE IF NOT EXISTS orders (
  order_id TEXT PRIMARY KEY CHECK (order_id LIKE 'sbx_%'),
  environment TEXT NOT NULL,
  merchant_id TEXT NOT NULL,
  buyer_id TEXT,
  currency TEXT NOT NULL CHECK (currency = 'CAD'),
  total_minor INTEGER NOT NULL,
  status TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS order_allocations (
  allocation_id TEXT PRIMARY KEY CHECK (allocation_id LIKE 'sbx_%'),
  order_id TEXT NOT NULL REFERENCES orders(order_id),
  bucket TEXT NOT NULL,
  amount_minor INTEGER NOT NULL,
  account_purpose TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS donation_campaigns (
  campaign_id TEXT PRIMARY KEY CHECK (campaign_id LIKE 'sbx_%'),
  environment TEXT NOT NULL,
  owner_id TEXT NOT NULL,
  title TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN (
    'DRAFT','VERIFICATION','ACTIVE_SANDBOX','PAUSED','COMPLETED','CLOSED'
  )),
  restricted_account_id TEXT REFERENCES accounts(account_id)
);

CREATE TABLE IF NOT EXISTS donation_pledges (
  pledge_id TEXT PRIMARY KEY,
  campaign_id TEXT NOT NULL REFERENCES donation_campaigns(campaign_id),
  donor_id TEXT NOT NULL,
  amount_minor INTEGER NOT NULL,
  status TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS reconciliation_runs (
  run_id TEXT PRIMARY KEY CHECK (run_id LIKE 'sbx_%'),
  environment TEXT NOT NULL,
  partner_position_minor INTEGER NOT NULL,
  platform_liability_minor INTEGER NOT NULL,
  difference_minor INTEGER NOT NULL,
  status TEXT NOT NULL,
  created_by TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS reconciliation_breaks (
  break_id TEXT PRIMARY KEY,
  run_id TEXT NOT NULL REFERENCES reconciliation_runs(run_id),
  description TEXT NOT NULL,
  amount_minor INTEGER NOT NULL,
  status TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS feature_flags (
  flag TEXT PRIMARY KEY,
  enabled INTEGER NOT NULL DEFAULT 0 CHECK (enabled = 0),
  note TEXT NOT NULL
);
"""

KILL_DEFAULTS = [
    "pause_new_registrations",
    "pause_payment_initiation",
    "pause_payouts",
    "pause_partner_rail",
    "pause_donation_disbursement",
    "global_money_off",
]


def connect(path: str = ":memory:") -> sqlite3.Connection:
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.executescript(SCHEMA)
    for code in KILL_DEFAULTS:
        conn.execute(
            "INSERT OR IGNORE INTO kill_switches(code, environment, active) VALUES (?,?,0)",
            (code, "sandbox"),
        )
    flags = [
        ("LIVE_MONEY_ENABLED", 0, "Sealed false"),
        ("DONATIONS_ENABLED", 0, "Schema only"),
        ("CROWDFUNDING_OFFERED", 0, "NOT_OFFERED"),
        ("CARDS_EXECUTION", 0, "Not compiled"),
        ("FX_EXECUTION", 0, "Not compiled"),
        ("REMITTANCE_EXECUTION", 0, "Not compiled"),
        ("KDN_PRODUCTION_WRITE", 0, "Forbidden in Phase 10.2"),
    ]
    for flag, enabled, note in flags:
        conn.execute(
            "INSERT OR IGNORE INTO feature_flags(flag, enabled, note) VALUES (?,?,?)",
            (flag, enabled, note),
        )
    conn.commit()
    return conn
