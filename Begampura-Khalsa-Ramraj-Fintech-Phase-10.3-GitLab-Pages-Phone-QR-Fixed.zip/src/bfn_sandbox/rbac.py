"""RBAC. ai_assistant never receives money-mutation or live-money permissions."""

from __future__ import annotations

from .errors import Forbidden

# permission codes
PERMS = {
    "intent.create",
    "intent.read.own",
    "intent.read.merchant",
    "intent.cancel",
    "intent.authorize",
    "settlement.mark_pending",
    "qr.issue",
    "qr.resolve",
    "invoice.create",
    "invoice.send",
    "refund.initiate",
    "payout.initiate",
    "payout.approve",
    "destination.change",
    "pi.read.limited",
    "pi.read.full",
    "metrics.read.store",
    "metrics.read.ops",
    "kill.switch",
    "recon.run",
    "ledger.read",
    "approval.decide",
    "audit.read",
    "webhook.ingest",
}

ROLE_PERMS: dict[str, set[str]] = {
    "customer": {"intent.read.own"},
    "cashier": {"intent.create", "intent.authorize", "settlement.mark_pending", "qr.issue", "qr.resolve", "intent.read.merchant", "metrics.read.store"},
    "finance": {
        "intent.create",
        "intent.authorize",
        "settlement.mark_pending",
        "intent.read.merchant",
        "invoice.create",
        "invoice.send",
        "refund.initiate",
        "payout.initiate",
        "payout.approve",
        "metrics.read.store",
        "ledger.read",
    },
    "owner": {
        "intent.create",
        "intent.authorize",
        "settlement.mark_pending",
        "intent.read.merchant",
        "intent.cancel",
    "intent.authorize",
    "settlement.mark_pending",
        "qr.issue",
        "qr.resolve",
        "invoice.create",
        "invoice.send",
        "refund.initiate",
        "payout.initiate",
        "payout.approve",
        "destination.change",
        "metrics.read.store",
        "ledger.read",
    },
    "support": {"intent.read.merchant", "pi.read.limited", "metrics.read.store"},
    "analyst": {"intent.read.merchant", "metrics.read.store", "ledger.read"},
    "platform_support": {"intent.read.merchant", "pi.read.limited", "metrics.read.ops"},
    "platform_compliance": {
        "intent.read.merchant",
        "pi.read.full",
        "metrics.read.ops",
        "ledger.read",
        "audit.read",
        "recon.run",
        "approval.decide",
        "payout.approve",
    },
    "platform_admin": {
        "metrics.read.ops",
        "audit.read",
        "kill.switch",
        "recon.run",
        "ledger.read",
    },
    "partner_tech": {"webhook.ingest"},
    "system": {"webhook.ingest", "ledger.read", "recon.run"},
    # Explicit empty money permissions. Do not add payout/settle/live.
    "ai_assistant": set(),
}

# live money is never a permission
FORBIDDEN_PERMISSIONS = {"live.money.enable", "live.money.flip", "settle.without.partner"}


def can(role: str, permission: str) -> bool:
    if permission in FORBIDDEN_PERMISSIONS:
        return False
    if role == "ai_assistant":
        return False
    return permission in ROLE_PERMS.get(role, set())


def require(role: str, permission: str) -> None:
    if not can(role, permission):
        raise Forbidden(f"role {role} cannot {permission}")
