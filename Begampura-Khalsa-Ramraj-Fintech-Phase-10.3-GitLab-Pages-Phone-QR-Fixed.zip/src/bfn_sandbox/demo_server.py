"""Phone-friendly Phase 10 sandbox demo server. No live-money rail exists here."""

from __future__ import annotations

import json
import mimetypes
import subprocess
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from .engine import Engine
from .errors import BfnError


ROOT = Path(__file__).resolve().parents[2]
WEB = ROOT / "web"
DB = ROOT / "phase10-demo.sqlite3"


class Demo:
    def __init__(self, db_path: Path | str = DB) -> None:
        self.engine = Engine(db_path=str(db_path))
        self.actors: dict[str, dict] = {}
        self.merchant: dict = {}
        self.latest: dict = {}
        self._bootstrap()

    def _user(self, handle: str, role: str) -> dict:
        row = self.engine.conn.execute(
            "SELECT user_id,handle,role FROM users WHERE handle=?", (handle,)
        ).fetchone()
        return dict(row) if row else self.engine.create_user(handle, role)

    def _bootstrap(self) -> None:
        self.actors["owner"] = self._user("demo_owner", "owner")
        self.actors["finance"] = self._user("demo_finance", "finance")
        row = self.engine.conn.execute(
            "SELECT merchant_id,status FROM merchants WHERE display_name='Demo Community Shop'"
        ).fetchone()
        if row:
            self.merchant = dict(row)
        else:
            self.merchant = self.engine.create_merchant(
                self.actors["owner"], "Demo Community Shop", "demo-merchant-v1"
            )
        member = self.engine.conn.execute(
            "SELECT 1 FROM merchant_members WHERE merchant_id=? AND user_id=? AND status='ACTIVE'",
            (self.merchant["merchant_id"], self.actors["finance"]["user_id"]),
        ).fetchone()
        if not member:
            self.engine.add_merchant_member(
                self.actors["owner"], self.merchant["merchant_id"], self.actors["finance"]
            )

    def state(self) -> dict:
        intent = self.latest.get("intent")
        if intent:
            intent = self.engine.get_intent(intent["payment_intent_id"])
        return {
            "environment": "sandbox",
            "live_money_enabled": False,
            "merchant": self.merchant,
            "intent": intent,
            "qr": self.latest.get("qr"),
            "payout": self.latest.get("payout"),
            "reconciliation": self.latest.get("reconciliation"),
        }

    def create(self, amount_minor: int) -> dict:
        key = f"demo-qr-{__import__('time').time_ns()}"
        qr = self.engine.issue_qr(
            self.actors["owner"], self.merchant["merchant_id"], "DYNAMIC", amount_minor, key
        )
        self.latest = {"qr": qr, "intent": self.engine.get_intent(qr["payment_intent_id"])}
        return self.state()

    def scan(self) -> dict:
        qr = self.latest["qr"]
        resolved = self.engine.resolve_qr(self.actors["owner"], qr["qr_token_id"])
        self.latest["resolved"] = resolved
        return {**self.state(), "resolved": resolved}

    def settle(self) -> dict:
        pid = self.latest["intent"]["payment_intent_id"]
        current = self.engine.get_intent(pid)
        if current["intent_status"] == "CREATED":
            self.engine.authorize_and_post(self.actors["owner"], pid)
        current = self.engine.get_intent(pid)
        if current["settlement_status"] == "POSTED":
            self.engine.mark_pending_settlement(self.actors["owner"], pid)
        self.engine.partner_settle(pid)
        return self.state()

    def payout(self) -> dict:
        pid = self.latest["intent"]["payment_intent_id"]
        pay = self.engine.conn.execute(
            "SELECT * FROM payables WHERE source_id=? ORDER BY rowid DESC LIMIT 1", (pid,)
        ).fetchone()
        if not pay:
            raise ValueError("Settle the sandbox payment first")
        payout = self.engine.request_payout(
            self.actors["owner"], pay["payable_id"], pay["eligible_minor"],
            "sbx_tok_demo_destination", f"demo-payout-{__import__('time').time_ns()}"
        )
        payout = self.engine.approve_payout(self.actors["finance"], payout["payout_id"])
        self.latest["payout"] = payout
        return self.state()

    def reconcile(self) -> dict:
        intent = self.engine.get_intent(self.latest["intent"]["payment_intent_id"])
        amount = intent["amount_minor"] if intent["settlement_status"] == "SETTLED" else 0
        result = self.engine.run_reconciliation(
            {"user_id": "sbx_user_system", "role": "system"}, amount, amount
        )
        self.latest["reconciliation"] = result
        return self.state()


DEMO = Demo()


class Handler(BaseHTTPRequestHandler):
    def _json(self, status: int, data: dict) -> None:
        body = json.dumps(data, ensure_ascii=False, default=str).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path == "/api/state":
            return self._json(200, DEMO.state())
        if parsed.path == "/api/qr.svg":
            value = parse_qs(parsed.query).get("value", [""])[0]
            if not value or len(value) > 512:
                return self._json(422, {"error": "invalid QR value"})
            proc = subprocess.run(
                ["node", str(WEB / "qr-svg.js"), value], capture_output=True, check=True
            )
            self.send_response(200)
            self.send_header("Content-Type", "image/svg+xml")
            self.send_header("Content-Length", str(len(proc.stdout)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            return self.wfile.write(proc.stdout)
        path = WEB / ("index.html" if parsed.path == "/" else parsed.path.lstrip("/"))
        if not path.is_file() or WEB not in path.resolve().parents:
            return self._json(404, {"error": "not found"})
        body = path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", mimetypes.guess_type(path.name)[0] or "application/octet-stream")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self) -> None:
        try:
            size = int(self.headers.get("Content-Length", "0"))
            data = json.loads(self.rfile.read(size) or b"{}")
            routes = {
                "/api/create": lambda: DEMO.create(data.get("amount_minor")),
                "/api/scan": DEMO.scan,
                "/api/settle": DEMO.settle,
                "/api/payout": DEMO.payout,
                "/api/reconcile": DEMO.reconcile,
            }
            if self.path not in routes:
                return self._json(404, {"error": "not found"})
            return self._json(200, routes[self.path]())
        except BfnError as exc:
            return self._json(exc.status_code, {"error": exc.code, "message": str(exc)})
        except (KeyError, TypeError, ValueError) as exc:
            return self._json(422, {"error": "UNPROCESSABLE", "message": str(exc)})

    def log_message(self, fmt: str, *args) -> None:
        print("[sandbox-demo] " + fmt % args)


def main() -> None:
    host, port = "127.0.0.1", 8080
    print(f"Phase 10 sandbox demo: http://{host}:{port}")
    print("LIVE_MONEY_ENABLED=false — no real funds can move")
    # The demo uses one SQLite connection, so requests are intentionally serialized.
    HTTPServer((host, port), Handler).serve_forever()


if __name__ == "__main__":
    main()
