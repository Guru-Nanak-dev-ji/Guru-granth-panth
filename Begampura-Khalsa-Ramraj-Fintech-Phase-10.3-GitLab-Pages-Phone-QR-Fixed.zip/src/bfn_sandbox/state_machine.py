"""Canonical Phase 10 payment state model. Replaces P3/P8/P9 vocabularies."""

from __future__ import annotations

from .errors import Unprocessable

INTENT = {
    "CREATED",
    "REQUIRES_ACTION",
    "AUTHORIZED",
    "CANCELLED",
    "EXPIRED",
    "FAILED",
}
SETTLEMENT = {
    "NOT_APPLICABLE",
    "POSTED",
    "PENDING_SETTLEMENT",
    "SETTLED",
    "RETURNED",
}
EXCEPTION = {"NONE", "REVERSED", "REFUNDED", "DISPUTED"}

# intent_status transitions
INTENT_TRANSITIONS = {
    "CREATED": {"REQUIRES_ACTION", "AUTHORIZED", "CANCELLED", "EXPIRED", "FAILED"},
    "REQUIRES_ACTION": {"AUTHORIZED", "EXPIRED", "CANCELLED", "FAILED"},
    "AUTHORIZED": {"CANCELLED", "FAILED"},  # money path continues via settlement_status
    "CANCELLED": set(),
    "EXPIRED": set(),
    "FAILED": set(),
}

# settlement_status transitions. SETTLED requires verified partner_event (enforced in payments).
SETTLEMENT_TRANSITIONS = {
    "NOT_APPLICABLE": {"POSTED"},
    "POSTED": {"PENDING_SETTLEMENT", "RETURNED"},
    "PENDING_SETTLEMENT": {"SETTLED", "RETURNED"},
    "SETTLED": set(),
    "RETURNED": set(),
}

EXCEPTION_TRANSITIONS = {
    "NONE": {"REVERSED", "REFUNDED", "DISPUTED"},
    "REVERSED": set(),
    "REFUNDED": {"DISPUTED"},
    "DISPUTED": {"REFUNDED"},
}

# Invoice: OVERDUE is only reachable from SENT / VIEWED / PARTIALLY_PAID.
INVOICE_TRANSITIONS = {
    "DRAFT": {"SENT", "CANCELLED"},
    "SENT": {"VIEWED", "PARTIALLY_PAID", "PAID", "OVERDUE", "CANCELLED"},
    "VIEWED": {"PARTIALLY_PAID", "PAID", "OVERDUE", "CANCELLED"},
    "PARTIALLY_PAID": {"PAID", "OVERDUE", "REFUNDED"},
    "PAID": {"REFUNDED"},
    "OVERDUE": {"PARTIALLY_PAID", "PAID", "CANCELLED"},
    "CANCELLED": set(),
    "REFUNDED": set(),
}

PAYOUT_TRANSITIONS = {
    "REQUESTED": {"VALIDATED", "CANCELLED", "FAILED"},
    "VALIDATED": {"APPROVED", "CANCELLED", "FAILED"},
    "APPROVED": {"SUBMITTED", "CANCELLED", "FAILED"},
    "SUBMITTED": {"PROCESSING", "FAILED"},
    "PROCESSING": {"SETTLED", "FAILED"},
    "SETTLED": set(),
    "FAILED": set(),
    "CANCELLED": set(),
}


def move(current: str, target: str, table: dict[str, set[str]], field: str) -> str:
    allowed = table.get(current, set())
    if target not in allowed:
        raise Unprocessable(f"illegal {field} transition {current} -> {target}")
    return target
