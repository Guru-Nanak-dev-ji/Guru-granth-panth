"""Webhook raw-body HMAC verification with key rotation, skew, and replay store."""

from __future__ import annotations

import hashlib
import hmac
import json
import time
from dataclasses import dataclass

from .errors import Unprocessable
from .ids import sbx


@dataclass
class WebhookKeys:
    active: tuple[str, str]  # kid, secret
    rotated: tuple[str, str] | None = None


def parse_signature(header: str) -> tuple[int, list[str]]:
    if not header:
        raise Unprocessable("missing signature header")
    timestamps: list[int] = []
    versions: list[str] = []
    for part in header.split(","):
        part = part.strip()
        if part.startswith("t="):
            try:
                timestamps.append(int(part[2:]))
            except (TypeError, ValueError) as e:
                raise Unprocessable("malformed signature header") from e
        elif part.startswith("v1=") and part[3:]:
            versions.append(part[3:])
    if len(timestamps) != 1 or not versions:
        raise Unprocessable("malformed signature header")
    return timestamps[0], versions


def signed_payload(timestamp: int, raw_body: bytes) -> bytes:
    return str(timestamp).encode("utf-8") + b"." + raw_body


def compute_v1(secret: str, timestamp: int, raw_body: bytes) -> str:
    return hmac.new(secret.encode("utf-8"), signed_payload(timestamp, raw_body), hashlib.sha256).hexdigest()


def verify_signature(
    raw_body: bytes,
    header: str,
    keys: WebhookKeys,
    now: int | None = None,
    skew_seconds: int = 300,
) -> tuple[str, int]:
    ts, versions = parse_signature(header)
    now = int(now if now is not None else time.time())
    if abs(now - ts) > skew_seconds:
        raise Unprocessable("signature timestamp outside clock skew")
    candidates = [keys.active]
    if keys.rotated:
        candidates.append(keys.rotated)
    for kid, secret in candidates:
        expected = compute_v1(secret, ts, raw_body)
        for provided in versions:
            if hmac.compare_digest(expected, provided):
                return kid, ts
    raise Unprocessable("invalid webhook signature")


def body_sha256(raw_body: bytes) -> str:
    return hashlib.sha256(raw_body).hexdigest()


def encode_event(event: dict) -> bytes:
    return json.dumps(event, separators=(",", ":"), sort_keys=True).encode("utf-8")


def make_header(secret: str, raw_body: bytes, timestamp: int | None = None) -> str:
    ts = int(timestamp if timestamp is not None else time.time())
    return f"t={ts},v1={compute_v1(secret, ts, raw_body)}"
