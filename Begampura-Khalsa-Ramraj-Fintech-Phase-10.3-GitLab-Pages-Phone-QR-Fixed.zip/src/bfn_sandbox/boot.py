"""Boot check entrypoint for the sealed Phase 10.2.1 sandbox."""

from __future__ import annotations

import sys

from .config import assert_boot_safe, load_config
from .errors import BootError


def main() -> int:
    path = sys.argv[1] if len(sys.argv) > 1 else None
    try:
        cfg = load_config(path) if path else None
        assert_boot_safe(cfg)
    except BootError as exc:
        print(f"BOOT REFUSED: {exc}", file=sys.stderr)
        return 2
    print("BFN Phase 10.2.1 boot-sealed sandbox boot OK; LIVE_MONEY_ENABLED=false")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
