from __future__ import annotations

import secrets


def sbx(kind: str) -> str:
    return f"sbx_{kind}_{secrets.token_hex(8)}"


def require_sbx(value: str) -> str:
    if not isinstance(value, str) or not value.startswith("sbx_"):
        raise ValueError("sandbox IDs must start with sbx_")
    return value
