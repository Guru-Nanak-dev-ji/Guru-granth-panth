"""Fail-closed sandbox engine. SETTLED only after a verified mock partner event."""

from __future__ import annotations

import hashlib
import json
import sqlite3
import time
from typing import Any

from . import rbac
from .config import assert_boot_safe, default_config
from .crypto_webhooks import WebhookKeys, body_sha256, encode_event, verify_signature
from .db import connect
from .errors import (
    BootError,
    Conflict,
    Forbidden,
    IdempotencyMismatch,
    KillSwitchActive,
    LedgerError,
    NotFound,
    Unprocessable,
)
from .ids import sbx
from .money import minor, require_cad
from .state_machine import (
    EXCEPTION_TRANSITIONS,
    INTENT_TRANSITIONS,
    INVOICE_TRANSITIONS,
    PAYOUT_TRANSITIONS,
    SETTLEMENT_TRANSITIONS,
    move,
)


class Engine:
    def __init__(self, cfg: dict | None = None, db_path: str = ":memory:"):
        self.cfg = assert_boot_safe(cfg or default_config())
        self.env = self.cfg["environment"]
        self.conn = connect(db_path)
        self.keys = WebhookKeys(
            active=("sbx_whsec_1", "sbx_webhook_secret_active_not_live"),
            rotated=("sbx_whsec_0", "sbx_webhook_secret_rotated_not_live"),
        )
        self._seed_system()

    def _seed_system(self) -> None:
        c = self.conn
        if c.execute("SELECT 1 FROM users WHERE user_id='sbx_user_system'").fetchone():
            return
        c.execute(
            "INSERT INTO users(user_id,environment,handle,role,status) VALUES (?,?,?,?,?)",
            ("sbx_user_system", self.env, "system", "system", "ACTIVE"),
        )
        for purpose, acc in {
            "operating": "sbx_acct_operating",
            "safeguarded_subledger": "sbx_acct_safeguarded",
            "customer_wallet": "sbx_acct_customer_pool",
            "merchant_receivable": "sbx_acct_recv_pool",
            "payable": "sbx_acct_payable_pool",
            "fee": "sbx_acct_fee",
            "donation_restricted": "sbx_acct_donation",
            "hold": "sbx_acct_hold",
        }.items():
            c.execute(
                """INSERT INTO accounts(account_id,environment,currency,book,owner_type,owner_id,purpose)
                   VALUES (?,?,?,?,?,?,?)""",
                (acc, self.env, "CAD", "SANDBOX_CASH", "platform", "sbx_user_system", purpose),
            )
        c.commit()

    # --- helpers ---
    def audit(self, actor: dict | None, action: str, **kwargs: Any) -> None:
        self.conn.execute(
            """INSERT INTO audit_events(audit_id,environment,actor_id,actor_role,action,
               resource_type,resource_id,before_state,after_state,reason_code)
               VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (
                sbx("aud"),
                self.env,
                (actor or {}).get("user_id"),
                (actor or {}).get("role"),
                action,
                kwargs.get("resource_type"),
                kwargs.get("resource_id"),
                kwargs.get("before"),
                kwargs.get("after"),
                kwargs.get("reason"),
            ),
        )

    def _kill(self, *codes: str) -> None:
        if self.conn.execute(
            "SELECT 1 FROM kill_switches WHERE active=1 AND code='global_money_off'"
        ).fetchone():
            raise KillSwitchActive("global_money_off")
        for code in codes:
            row = self.conn.execute(
                "SELECT active FROM kill_switches WHERE code=?", (code,)
            ).fetchone()
            if row and row["active"]:
                raise KillSwitchActive(code)

    def set_kill_switch(self, actor: dict, code: str, active: bool, reason: str = "") -> None:
        self._active_actor(actor)
        rbac.require(actor["role"], "kill.switch")
        cur = self.conn.execute(
            "UPDATE kill_switches SET active=?, reason=?, activated_by=? WHERE code=?",
            (1 if active else 0, reason, actor["user_id"], code),
        )
        if cur.rowcount != 1:
            raise NotFound("kill_switch")
        self.audit(actor, "kill_switch", resource_id=code, after=str(active), reason=reason)
        self.conn.commit()

    PUBLIC_USER_ROLES = frozenset({
        "customer", "cashier", "finance", "owner", "support", "analyst", "ai_assistant"
    })
    PRIVILEGED_SEED_ROLES = frozenset({
        "platform_support", "platform_compliance", "platform_admin", "partner_tech", "system"
    })

    def _insert_user(self, handle: str, role: str) -> dict:
        if role not in rbac.ROLE_PERMS:
            raise Unprocessable("unknown role")
        if not isinstance(handle, str) or not handle.strip():
            raise Unprocessable("handle required")
        uid = sbx("user")
        try:
            self.conn.execute(
                "INSERT INTO users(user_id,environment,handle,role,status) VALUES (?,?,?,?,?)",
                (uid, self.env, handle.strip(), role, "ACTIVE"),
            )
        except sqlite3.IntegrityError as e:
            raise Unprocessable("user rejected") from e
        self.conn.commit()
        return {"user_id": uid, "role": role, "handle": handle.strip()}

    def create_user(self, handle: str, role: str) -> dict:
        """Create only non-platform sandbox principals; privileged identities are seed-only."""
        if role not in self.PUBLIC_USER_ROLES:
            raise Forbidden("privileged role is seed-only")
        return self._insert_user(handle, role)

    def _seed_user(self, handle: str, role: str) -> dict:
        """Internal fixture/bootstrap helper. Not an API surface."""
        if role not in self.PRIVILEGED_SEED_ROLES:
            raise Forbidden("_seed_user is only for privileged sandbox roles")
        return self._insert_user(handle, role)

    def _active_actor(self, actor: dict) -> sqlite3.Row:
        """Resolve actor from the database; never trust a caller-supplied role alone."""
        user_id = (actor or {}).get("user_id")
        role = (actor or {}).get("role")
        row = self.conn.execute(
            "SELECT user_id, role, status FROM users WHERE user_id=?", (user_id,)
        ).fetchone()
        if not row or row["status"] != "ACTIVE" or row["role"] != role:
            raise Forbidden("inactive or invalid actor")
        return row

    def _require_merchant_member(
        self, actor: dict, merchant_id: str, allowed_member_roles: set[str] | None = None
    ) -> sqlite3.Row:
        """Require an ACTIVE membership on the exact merchant being mutated/read."""
        self._active_actor(actor)
        row = self.conn.execute(
            """SELECT merchant_id, user_id, role, status FROM merchant_members
               WHERE merchant_id=? AND user_id=?""",
            (merchant_id, actor["user_id"]),
        ).fetchone()
        if not row or row["status"] != "ACTIVE":
            raise Forbidden("active merchant membership required")
        if row["role"] != actor["role"]:
            raise Forbidden("merchant membership role mismatch")
        if allowed_member_roles and row["role"] not in allowed_member_roles:
            raise Forbidden("merchant member role not permitted")
        return row

    def add_merchant_member(self, owner: dict, merchant_id: str, user: dict, member_role: str | None = None) -> None:
        """Sandbox administration helper. Only an active owner of this merchant may add members."""
        self._require_merchant_member(owner, merchant_id, {"owner"})
        self._active_actor(user)
        role = member_role or user["role"]
        if role not in {"owner", "finance", "cashier", "support", "analyst"}:
            raise Unprocessable("invalid merchant member role")
        if role != user["role"]:
            raise Unprocessable("merchant member role must match stored user role")
        self.conn.execute(
            """INSERT INTO merchant_members(merchant_id,user_id,role,status) VALUES (?,?,?,'ACTIVE')
               ON CONFLICT(merchant_id,user_id) DO UPDATE SET role=excluded.role,status='ACTIVE'""",
            (merchant_id, user["user_id"], role),
        )
        self.conn.commit()

    def set_merchant_member_status(self, owner: dict, merchant_id: str, user_id: str, status: str) -> None:
        self._require_merchant_member(owner, merchant_id, {"owner"})
        if status not in {"ACTIVE", "REVOKED"}:
            raise Unprocessable("invalid merchant member status")
        if user_id == owner["user_id"] and status == "REVOKED":
            raise Unprocessable("owner cannot revoke self in sandbox helper")
        cur = self.conn.execute(
            "UPDATE merchant_members SET status=? WHERE merchant_id=? AND user_id=?",
            (status, merchant_id, user_id),
        )
        if cur.rowcount != 1:
            raise NotFound("merchant_member")
        self.conn.commit()

    def create_merchant(
        self, owner: dict, display_name: str, idempotency_key: str | None = None
    ) -> dict:
        self._active_actor(owner)
        if owner["role"] != "owner":
            raise Forbidden("only owner role may create a merchant")
        self._kill("pause_new_registrations", "global_money_off")
        if not isinstance(display_name, str) or not display_name.strip():
            raise Unprocessable("display_name required")
        body = {"display_name": display_name.strip()}
        existing = self.begin_idempotent(owner, "POST /v1/merchants", idempotency_key, body)
        if existing:
            row = self.conn.execute(
                "SELECT merchant_id,status FROM merchants WHERE merchant_id=?",
                (existing["resource_id"],),
            ).fetchone()
            if not row:
                raise Conflict("idempotency resource missing")
            return dict(row)
        mid = sbx("merch")
        try:
            self.conn.execute(
                """INSERT INTO merchants(merchant_id,environment,display_name,status,risk_tier)
                   VALUES (?,?,?,?,?)""",
                (mid, self.env, body["display_name"], "SANDBOX_ACTIVE", "S0"),
            )
        except sqlite3.IntegrityError as e:
            raise Unprocessable("merchant state rejected") from e
        self.conn.execute(
            "INSERT INTO merchant_members(merchant_id,user_id,role,status) VALUES (?,?,?,?)",
            (mid, owner["user_id"], "owner", "ACTIVE"),
        )
        self.store_idempotent(owner, "POST /v1/merchants", idempotency_key, body, "merchant", mid)
        self.audit(owner, "merchant.create", resource_type="merchant", resource_id=mid)
        self.conn.commit()
        return {"merchant_id": mid, "status": "SANDBOX_ACTIVE"}

    def try_set_merchant_live(self, merchant_id: str) -> None:
        try:
            self.conn.execute(
                "UPDATE merchants SET status=? WHERE merchant_id=?",
                ("LIVE_ACTIVE", merchant_id),
            )
            self.conn.commit()
        except sqlite3.IntegrityError as e:
            raise Unprocessable("LIVE_ACTIVE transition impossible") from e
        raise Unprocessable("LIVE_ACTIVE transition impossible")

    # --- ledger ---
    def post_journal(
        self,
        actor: dict,
        source_type: str,
        source_id: str,
        legs: list[tuple[str, int, int]],
        reverses: str | None = None,
    ) -> str:
        """legs: (account_id, debit_minor, credit_minor). Fail-closed if unbalanced."""
        if not legs:
            raise LedgerError("empty journal")
        debit = sum(d for _, d, _ in legs)
        credit = sum(c for _, _, c in legs)
        if debit != credit:
            raise LedgerError("journal debit total must equal credit total")
        for account_id, d, c in legs:
            if (d > 0 and c > 0) or (d == 0 and c == 0) or d < 0 or c < 0:
                raise LedgerError("each leg must be a single debit or credit")
            acc = self.conn.execute(
                "SELECT purpose, book, currency FROM accounts WHERE account_id=?",
                (account_id,),
            ).fetchone()
            if not acc:
                raise LedgerError("unknown account")
            if acc["currency"] != "CAD" or acc["book"] != "SANDBOX_CASH":
                raise LedgerError("cross-book or non-CAD posting forbidden")
        jid = sbx("jnl")
        try:
            self.conn.execute(
                """INSERT INTO ledger_journals(journal_id,environment,source_type,source_id,sealed,
                   reverses_journal_id,created_by) VALUES (?,?,?,?,0,?,?)""",
                (jid, self.env, source_type, source_id, reverses, actor["user_id"]),
            )
        except sqlite3.IntegrityError as e:
            raise Conflict("duplicate journal source") from e
        for account_id, d, c in legs:
            self.conn.execute(
                """INSERT INTO ledger_entries(entry_id,journal_id,account_id,currency,debit_minor,credit_minor)
                   VALUES (?,?,?,?,?,?)""",
                (sbx("ent"), jid, account_id, "CAD", d, c),
            )
        self.conn.execute("UPDATE ledger_journals SET sealed=1 WHERE journal_id=?", (jid,))
        self.audit(actor, "journal.post", resource_type="journal", resource_id=jid)
        return jid

    def bulk_balanced_journals(self, actor: dict, count: int) -> int:
        """Property-test helper: insert `count` sealed 2-leg CAD journals."""
        journals = []
        entries = []
        for i in range(count):
            jid = f"sbx_jnl_load_{i:06d}"
            amt = (i % 97) + 1
            journals.append((jid, self.env, "load", f"sbx_src_load_{i}", 1, actor["user_id"]))
            entries.append((f"sbx_ent_l_{i}_d", jid, "sbx_acct_customer_pool", "CAD", amt, 0))
            entries.append((f"sbx_ent_l_{i}_c", jid, "sbx_acct_hold", "CAD", 0, amt))
        self.conn.execute("BEGIN")
        self.conn.executemany(
            """INSERT INTO ledger_journals(journal_id,environment,source_type,source_id,sealed,created_by)
               VALUES (?,?,?,?,?,?)""",
            journals,
        )
        self.conn.executemany(
            """INSERT INTO ledger_entries(entry_id,journal_id,account_id,currency,debit_minor,credit_minor)
               VALUES (?,?,?,?,?,?)""",
            entries,
        )
        self.conn.commit()
        return count

    def reverse_journal(self, actor: dict, journal_id: str) -> str:
        rows = self.conn.execute(
            """SELECT account_id, debit_minor, credit_minor FROM ledger_entries WHERE journal_id=?""",
            (journal_id,),
        ).fetchall()
        if not rows:
            raise NotFound("journal")
        legs = [(r["account_id"], r["credit_minor"], r["debit_minor"]) for r in rows]
        return self.post_journal(actor, "reversal", journal_id, legs, reverses=journal_id)

    def mutate_entry(self, entry_id: str, **fields: Any) -> None:
        if fields:
            sets = ", ".join(f"{k}=?" for k in fields)
            try:
                self.conn.execute(f"UPDATE ledger_entries SET {sets} WHERE entry_id=?", (*fields.values(), entry_id))
            except sqlite3.IntegrityError as e:
                raise LedgerError(str(e)) from e
        self.conn.commit()

    def delete_entry(self, entry_id: str) -> None:
        try:
            self.conn.execute("DELETE FROM ledger_entries WHERE entry_id=?", (entry_id,))
            self.conn.commit()
        except sqlite3.IntegrityError as e:
            raise LedgerError(str(e)) from e

    def journal_balanced(self, journal_id: str) -> bool:
        row = self.conn.execute(
            """SELECT SUM(debit_minor) d, SUM(credit_minor) c FROM ledger_entries WHERE journal_id=?""",
            (journal_id,),
        ).fetchone()
        return bool(row) and row["d"] == row["c"]

    # --- idempotency ---
    def begin_idempotent(self, actor: dict, route: str, key: str | None, body: dict) -> dict | None:
        if not isinstance(key, str) or not key.strip():
            raise Unprocessable("Idempotency-Key required")
        try:
            encoded = json.dumps(body, sort_keys=True, separators=(",", ":")).encode()
        except (TypeError, ValueError) as e:
            raise Unprocessable("request body is not valid JSON data") from e
        body_hash = hashlib.sha256(encoded).hexdigest()
        row = self.conn.execute(
            """SELECT body_hash, resource_id, resource_type, status_code FROM idempotency_keys
               WHERE environment=? AND principal_id=? AND route=? AND idempotency_key=?""",
            (self.env, actor["user_id"], route, key),
        ).fetchone()
        if row:
            if row["body_hash"] != body_hash:
                raise IdempotencyMismatch("Idempotency-Key reused with different body")
            return dict(row)
        return None

    def store_idempotent(self, actor: dict, route: str, key: str, body: dict, resource_type: str, resource_id: str) -> None:
        if not isinstance(key, str) or not key.strip():
            raise Unprocessable("Idempotency-Key required")
        try:
            encoded = json.dumps(body, sort_keys=True, separators=(",", ":")).encode()
        except (TypeError, ValueError) as e:
            raise Unprocessable("request body is not valid JSON data") from e
        body_hash = hashlib.sha256(encoded).hexdigest()
        self.conn.execute(
            """INSERT INTO idempotency_keys(environment,principal_id,route,idempotency_key,body_hash,
               resource_type,resource_id,status_code) VALUES (?,?,?,?,?,?,?,201)""",
            (self.env, actor["user_id"], route, key, body_hash, resource_type, resource_id),
        )

    def get_intent(self, payment_intent_id: str) -> dict:
        row = self.conn.execute(
            "SELECT * FROM payment_intents WHERE payment_intent_id=?", (payment_intent_id,)
        ).fetchone()
        if not row:
            raise NotFound("payment_intent")
        return dict(row)

    # --- payments ---
    def create_intent(self, actor: dict, body: dict, idempotency_key: str) -> dict:
        self._active_actor(actor)
        rbac.require(actor["role"], "intent.create")
        self._kill("pause_payment_initiation")
        if not isinstance(body, dict):
            raise Unprocessable("request body must be an object")

        merchant_id = body.get("merchant_id")
        if not isinstance(merchant_id, str) or not merchant_id.strip():
            raise Unprocessable("merchant_id required")
        merchant_id = merchant_id.strip()
        self._require_merchant_member(actor, merchant_id, {"owner", "finance", "cashier"})

        if "amount_minor" not in body:
            raise Unprocessable("amount_minor required")
        amount = minor(body["amount_minor"])
        if "currency" not in body:
            raise Unprocessable("currency required")
        require_cad(body["currency"])

        payer_id = body.get("payer_id")
        if payer_id is not None:
            if not isinstance(payer_id, str) or not payer_id.strip():
                raise Unprocessable("payer_id must be a non-empty string")
            payer_id = payer_id.strip()
            payer = self.conn.execute(
                "SELECT 1 FROM users WHERE user_id=? AND status='ACTIVE'", (payer_id,)
            ).fetchone()
            if not payer:
                raise Unprocessable("unknown payer_id")

        purpose = body.get("purpose", "merchant_sale")
        if purpose == "donation":
            raise Unprocessable("donation money flow is disabled until classification memo")
        if purpose not in {"merchant_sale", "invoice", "payout_funding", "marketplace_order", "sandbox_transfer"}:
            raise Unprocessable("purpose not offered")

        normalized_body = dict(body)
        normalized_body["merchant_id"] = merchant_id
        normalized_body["amount_minor"] = amount
        normalized_body["currency"] = "CAD"
        if payer_id is not None:
            normalized_body["payer_id"] = payer_id
        existing = self.begin_idempotent(
            actor, "POST /v1/payment-intents", idempotency_key, normalized_body
        )
        if existing:
            return self.get_intent(existing["resource_id"])

        pid = sbx("pi")
        try:
            self.conn.execute(
                """INSERT INTO payment_intents(payment_intent_id,environment,merchant_id,payer_id,amount_minor,
                   currency,intent_status,settlement_status,exception_status,purpose,invoice_id,order_id)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    pid,
                    self.env,
                    merchant_id,
                    payer_id,
                    amount,
                    "CAD",
                    "CREATED",
                    "NOT_APPLICABLE",
                    "NONE",
                    purpose,
                    body.get("invoice_id"),
                    body.get("order_id"),
                ),
            )
        except sqlite3.IntegrityError as e:
            self.conn.rollback()
            raise Unprocessable("payment intent rejected") from e
        self.store_idempotent(
            actor, "POST /v1/payment-intents", idempotency_key, normalized_body, "payment_intent", pid
        )
        self.audit(actor, "intent.create", resource_type="payment_intent", resource_id=pid)
        self.conn.commit()
        return self.get_intent(pid)

    def authorize_and_post(self, actor: dict, payment_intent_id: str) -> dict:
        """Internal sandbox step: authorize + post hold. Does NOT settle."""
        self._active_actor(actor)
        rbac.require(actor["role"], "intent.authorize")
        self._kill("pause_payment_initiation")
        intent = self.get_intent(payment_intent_id)
        merchant_id = intent["merchant_id"]
        if not merchant_id:
            raise Unprocessable("merchant-bound intent required")
        self._require_merchant_member(actor, merchant_id, {"owner", "finance", "cashier"})
        new_intent = move(intent["intent_status"], "AUTHORIZED", INTENT_TRANSITIONS, "intent_status")
        new_settle = move(intent["settlement_status"], "POSTED", SETTLEMENT_TRANSITIONS, "settlement_status")
        self.post_journal(
            actor,
            "payment_intent_post",
            payment_intent_id,
            [
                ("sbx_acct_customer_pool", intent["amount_minor"], 0),
                ("sbx_acct_hold", 0, intent["amount_minor"]),
            ],
        )
        self.conn.execute(
            """UPDATE payment_intents SET intent_status=?, settlement_status=? WHERE payment_intent_id=?""",
            (new_intent, new_settle, payment_intent_id),
        )
        self.conn.commit()
        return self.get_intent(payment_intent_id)

    def mark_pending_settlement(self, actor: dict, payment_intent_id: str) -> dict:
        self._active_actor(actor)
        rbac.require(actor["role"], "settlement.mark_pending")
        self._kill("pause_partner_rail")
        intent = self.get_intent(payment_intent_id)
        merchant_id = intent["merchant_id"]
        if not merchant_id:
            raise Unprocessable("merchant-bound intent required")
        self._require_merchant_member(actor, merchant_id, {"owner", "finance", "cashier"})
        st = move(intent["settlement_status"], "PENDING_SETTLEMENT", SETTLEMENT_TRANSITIONS, "settlement_status")
        self.conn.execute(
            "UPDATE payment_intents SET settlement_status=? WHERE payment_intent_id=?",
            (st, payment_intent_id),
        )
        self.conn.commit()
        return self.get_intent(payment_intent_id)

    def frontend_success(self, payment_intent_id: str) -> dict:
        """Browser cannot settle. Returns current intent unchanged."""
        return self.get_intent(payment_intent_id)

    def _apply_settled(self, actor: dict, intent: dict) -> None:
        if intent["settlement_status"] == "SETTLED":
            return
        st = move(intent["settlement_status"], "SETTLED", SETTLEMENT_TRANSITIONS, "settlement_status")
        self.post_journal(
            actor,
            "payment_intent_settle",
            intent["payment_intent_id"] + ":settle",
            [
                ("sbx_acct_hold", intent["amount_minor"], 0),
                ("sbx_acct_recv_pool", 0, intent["amount_minor"]),
            ],
        )
        self.conn.execute(
            "UPDATE payment_intents SET settlement_status=? WHERE payment_intent_id=?",
            (st, intent["payment_intent_id"]),
        )
        if intent["merchant_id"]:
            pay_id = sbx("payble")
            self.conn.execute(
                """INSERT INTO payables(payable_id,environment,source_type,source_id,merchant_id,beneficiary_id,
                   currency,eligible_minor,source_settled,status)
                   VALUES (?,?,?,?,?,?,?,?,1,'OPEN')""",
                (
                    pay_id,
                    self.env,
                    "payment_intent",
                    intent["payment_intent_id"],
                    intent["merchant_id"],
                    intent["merchant_id"],
                    "CAD",
                    intent["amount_minor"],
                ),
            )

    # --- mock partner + webhooks ---
    def mock_partner_emit(self, event_type: str, payment_intent_id: str, external_event_id: str | None = None) -> dict:
        event = {
            "partner_source": "mock_partner",
            "event_type": event_type,
            "payment_intent_id": payment_intent_id,
            "external_event_id": external_event_id or sbx("pevt"),
        }
        raw = encode_event(event)
        header = None  # caller signs
        return {"event": event, "raw": raw}

    def ingest_webhook(
        self, actor: dict, raw_body: bytes, signature_header: str, now: int | None = None
    ) -> dict:
        """Authenticated partner ingest: verify HMAC before reserving replay identity."""
        self._active_actor(actor)
        rbac.require(actor["role"], "webhook.ingest")
        self._kill("pause_partner_rail")
        skew = int(self.cfg["webhook"]["clock_skew_seconds"])
        sha = body_sha256(raw_body)

        # Authenticate raw bytes before trusting any attacker-controlled event identifier.
        _, verified_ts = verify_signature(
            raw_body, signature_header, self.keys, now=now, skew_seconds=skew
        )
        try:
            event = json.loads(raw_body.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as e:
            raise Unprocessable("invalid webhook json") from e
        if not isinstance(event, dict):
            raise Unprocessable("webhook body must be an object")

        source = event.get("partner_source")
        ext_id = event.get("external_event_id")
        event_type = event.get("event_type")
        payment_intent_id = event.get("payment_intent_id")
        if source != "mock_partner":
            raise Unprocessable("unknown partner_source")
        if not isinstance(ext_id, str) or not ext_id.strip():
            raise Unprocessable("external_event_id required")
        if len(ext_id) > 255:
            raise Unprocessable("external_event_id too long")
        if event_type not in {"settled", "authorized", "posted"}:
            raise Unprocessable("unknown event_type")
        if not isinstance(payment_intent_id, str) or not payment_intent_id.strip():
            raise Unprocessable("payment_intent_id required")

        intent_row = self.conn.execute(
            "SELECT * FROM payment_intents WHERE payment_intent_id=?",
            (payment_intent_id,),
        ).fetchone()
        if not intent_row:
            raise Unprocessable("unknown payment_intent_id")
        intent = dict(intent_row)

        existing = self.conn.execute(
            """SELECT r.disposition, r.raw_body_sha256
               FROM webhook_receipts r
               WHERE r.environment=? AND r.partner_source=? AND r.external_event_id=?""",
            (self.env, source, ext_id),
        ).fetchone()
        if existing:
            if existing["raw_body_sha256"] != sha:
                raise Conflict("external_event_id reused with different payload")
            return {"disposition": "REPLAY", "duplicate": True}

        rid = sbx("wh")
        peid = sbx("pe")
        try:
            self.conn.execute(
                """INSERT INTO webhook_receipts(receipt_id,environment,partner_source,external_event_id,
                   timestamp_unix,verified,disposition,raw_body_sha256) VALUES (?,?,?,?,?,?,?,?)""",
                (rid, self.env, source, ext_id, verified_ts, 1, "ACCEPTED", sha),
            )
            self.conn.execute(
                """INSERT INTO partner_events(partner_event_id,environment,partner_source,external_event_id,
                   event_type,payment_intent_id,payload_hash,verified) VALUES (?,?,?,?,?,?,?,1)""",
                (peid, self.env, source, ext_id, event_type, payment_intent_id, sha),
            )
        except sqlite3.IntegrityError as e:
            self.conn.rollback()
            raise Conflict("duplicate webhook event") from e

        actor = {"user_id": "sbx_user_system", "role": "system"}
        if event_type == "settled":
            if intent["settlement_status"] == "SETTLED":
                self.conn.execute(
                    "UPDATE webhook_receipts SET disposition='REPLAY' WHERE receipt_id=?", (rid,)
                )
                self.conn.commit()
                return {"disposition": "REPLAY", "partner_event_id": peid}
            try:
                self._apply_settled(actor, intent)
            except Unprocessable:
                self.conn.execute(
                    "UPDATE webhook_receipts SET disposition='IGNORED_OUT_OF_ORDER' WHERE receipt_id=?",
                    (rid,),
                )
                self.conn.commit()
                return {"disposition": "IGNORED_OUT_OF_ORDER", "partner_event_id": peid}
        elif event_type in {"authorized", "posted"} and intent["settlement_status"] == "SETTLED":
            self.conn.execute(
                "UPDATE webhook_receipts SET disposition='IGNORED_OUT_OF_ORDER' WHERE receipt_id=?",
                (rid,),
            )
            self.conn.commit()
            return {"disposition": "IGNORED_OUT_OF_ORDER", "partner_event_id": peid}
        self.conn.commit()
        return {"disposition": "ACCEPTED", "partner_event_id": peid}

    def partner_settle(self, payment_intent_id: str, now: int | None = None) -> dict:
        """Internal mock adapter helper; still obeys partner-rail kill switch and HMAC."""
        self._kill("pause_partner_rail")
        bundle = self.mock_partner_emit("settled", payment_intent_id)
        from .crypto_webhooks import make_header

        header = make_header(self.keys.active[1], bundle["raw"], timestamp=now)
        actor = {"user_id": "sbx_user_system", "role": "system"}
        return self.ingest_webhook(actor, bundle["raw"], header, now=now)

    # --- QR ---
    def issue_qr(
        self,
        actor: dict,
        merchant_id: str,
        kind: str,
        amount_minor: int | None = None,
        idempotency_key: str | None = None,
    ) -> dict:
        self._active_actor(actor)
        rbac.require(actor["role"], "qr.issue")
        self._require_merchant_member(actor, merchant_id)
        if kind not in {"STATIC", "DYNAMIC"}:
            raise Unprocessable("invalid QR kind")
        if kind == "DYNAMIC" and amount_minor is None:
            raise Unprocessable("dynamic QR requires amount")
        normalized_amount = minor(amount_minor) if amount_minor is not None else None
        route = "POST /v1/qr/dynamic" if kind == "DYNAMIC" else "POST /v1/qr/static"
        body = {"merchant_id": merchant_id, "kind": kind, "amount_minor": normalized_amount}
        existing = self.begin_idempotent(actor, route, idempotency_key, body)
        if existing:
            row = self.conn.execute(
                "SELECT * FROM qr_tokens WHERE qr_token_id=?", (existing["resource_id"],)
            ).fetchone()
            if not row:
                raise Conflict("idempotency resource missing")
            return {
                "qr_token_id": row["qr_token_id"],
                "payment_intent_id": row["payment_intent_id"],
                "qr_kind": row["qr_kind"],
                "reference": row["qr_token_id"],
            }
        nonce = sbx("nonce")
        payload = f"{merchant_id}:{kind}:{normalized_amount or ''}:{nonce}"
        token = sbx("qr")
        import hmac as hm

        digest = hm.new(self.keys.active[1].encode(), payload.encode(), hashlib.sha256).hexdigest()
        pi = None
        if kind == "DYNAMIC":
            pi = self.create_intent(
                actor,
                {
                    "merchant_id": merchant_id,
                    "amount_minor": normalized_amount,
                    "currency": "CAD",
                    "purpose": "merchant_sale",
                },
                idempotency_key=f"{idempotency_key}:intent",
            )["payment_intent_id"]
        expires = int(time.time()) + 300 if kind == "DYNAMIC" else None
        self.conn.execute(
            """INSERT INTO qr_tokens(qr_token_id,environment,qr_kind,merchant_id,payment_intent_id,nonce,
               payload_hmac,amount_minor,consumed,expires_at) VALUES (?,?,?,?,?,?,?,?,0,?)""",
            (token, self.env, kind, merchant_id, pi, nonce, digest, normalized_amount, expires),
        )
        self.store_idempotent(actor, route, idempotency_key, body, "qr_token", token)
        self.conn.commit()
        return {"qr_token_id": token, "payment_intent_id": pi, "qr_kind": kind, "reference": token}

    def resolve_qr(self, actor: dict, qr_token_id: str, presented_amount: int | None = None) -> dict:
        self._active_actor(actor)
        rbac.require(actor["role"], "qr.resolve")
        row = self.conn.execute("SELECT * FROM qr_tokens WHERE qr_token_id=?", (qr_token_id,)).fetchone()
        if not row:
            raise NotFound("qr")
        self._require_merchant_member(actor, row["merchant_id"])
        if row["consumed"]:
            raise Unprocessable("QR already consumed")
        if row["expires_at"] and int(time.time()) > int(row["expires_at"]):
            raise Unprocessable("QR expired")
        merch = self.conn.execute(
            "SELECT display_name FROM merchants WHERE merchant_id=?", (row["merchant_id"],)
        ).fetchone()
        amount = row["amount_minor"] if row["qr_kind"] == "DYNAMIC" else presented_amount
        if row["qr_kind"] == "DYNAMIC" and presented_amount and presented_amount != row["amount_minor"]:
            amount = row["amount_minor"]  # server amount wins
        return {
            "merchant_id": row["merchant_id"],
            "merchant_display_name": merch["display_name"] if merch else "",
            "amount_minor": amount,
            "currency": "CAD",
            "payment_intent_id": row["payment_intent_id"],
        }

    # --- invoices ---
    def create_invoice(
        self, actor: dict, merchant_id: str, total_minor: int, idempotency_key: str | None = None
    ) -> dict:
        self._active_actor(actor)
        rbac.require(actor["role"], "invoice.create")
        self._require_merchant_member(actor, merchant_id)
        total = minor(total_minor)
        body = {"merchant_id": merchant_id, "total_minor": total, "currency": "CAD"}
        existing = self.begin_idempotent(actor, "POST /v1/invoices", idempotency_key, body)
        if existing:
            row = self.conn.execute(
                "SELECT * FROM invoices WHERE invoice_id=?", (existing["resource_id"],)
            ).fetchone()
            if not row:
                raise Conflict("idempotency resource missing")
            return dict(row)
        iid = sbx("inv")
        self.conn.execute(
            """INSERT INTO invoices(invoice_id,environment,merchant_id,status,currency,total_minor,paid_minor)
               VALUES (?,?,?,'DRAFT','CAD',?,0)""",
            (iid, self.env, merchant_id, total),
        )
        self.store_idempotent(actor, "POST /v1/invoices", idempotency_key, body, "invoice", iid)
        self.conn.commit()
        return dict(self.conn.execute("SELECT * FROM invoices WHERE invoice_id=?", (iid,)).fetchone())

    def transition_invoice(self, actor: dict, invoice_id: str, target: str) -> dict:
        self._active_actor(actor)
        rbac.require(actor["role"], "invoice.send")
        row = self.conn.execute("SELECT * FROM invoices WHERE invoice_id=?", (invoice_id,)).fetchone()
        if not row:
            raise NotFound("invoice")
        self._require_merchant_member(actor, row["merchant_id"], {"owner", "finance"})
        if target not in {"SENT", "CANCELLED"}:
            raise Unprocessable("invoice target is not manually offered")
        move(row["status"], target, INVOICE_TRANSITIONS, "invoice_status")
        self.conn.execute("UPDATE invoices SET status=? WHERE invoice_id=?", (target, invoice_id))
        self.audit(actor, "invoice.transition", resource_type="invoice", resource_id=invoice_id, before=row["status"], after=target)
        self.conn.commit()
        return dict(self.conn.execute("SELECT * FROM invoices WHERE invoice_id=?", (invoice_id,)).fetchone())

    # --- payouts ---
    def request_payout(self, actor: dict, payable_id: str, amount_minor: int, dest: str, idempotency_key: str) -> dict:
        self._active_actor(actor)
        rbac.require(actor["role"], "payout.initiate")
        self._kill("pause_payouts")
        pay = self.conn.execute("SELECT * FROM payables WHERE payable_id=?", (payable_id,)).fetchone()
        if not pay:
            raise NotFound("payable")
        if pay["merchant_id"]:
            self._require_merchant_member(actor, pay["merchant_id"])
        body = {"payable_id": payable_id, "amount_minor": amount_minor, "destination": dest}
        existing = self.begin_idempotent(actor, "POST /v1/payouts", idempotency_key, body)
        if existing:
            row = self.conn.execute(
                "SELECT * FROM payouts WHERE payout_id=?", (existing["resource_id"],)
            ).fetchone()
            if not row:
                raise Conflict("idempotency resource missing")
            return dict(row)
        if not pay["source_settled"]:
            raise Unprocessable("payout cannot consume unsettled funds")
        amt = minor(amount_minor)
        available = pay["eligible_minor"] - pay["reserved_minor"] - pay["paid_minor"]
        if amt > available:
            raise Unprocessable("payout exceeds settled eligible amount")
        pid = sbx("payout")
        self.conn.execute(
            """INSERT INTO payouts(payout_id,environment,payable_id,amount_minor,currency,destination_token_ref,
               status,requested_by,reconciliation_key) VALUES (?,?,?,?,?,?,?,?,?)""",
            (pid, self.env, payable_id, amt, "CAD", dest, "VALIDATED", actor["user_id"], sbx("recon")),
        )
        self.conn.execute(
            "UPDATE payables SET reserved_minor = reserved_minor + ? WHERE payable_id=?",
            (amt, payable_id),
        )
        self.store_idempotent(actor, "POST /v1/payouts", idempotency_key, body, "payout", pid)
        self.conn.execute(
            """INSERT INTO approvals(approval_id,environment,resource_type,resource_id,action,requested_by,status)
               VALUES (?,?,?,?,?,?,?)""",
            (sbx("appr"), self.env, "payout", pid, "approve", actor["user_id"], "PENDING"),
        )
        self.conn.commit()
        return dict(self.conn.execute("SELECT * FROM payouts WHERE payout_id=?", (pid,)).fetchone())

    def approve_payout(self, actor: dict, payout_id: str) -> dict:
        self._active_actor(actor)
        rbac.require(actor["role"], "payout.approve")
        po = self.conn.execute("SELECT * FROM payouts WHERE payout_id=?", (payout_id,)).fetchone()
        if not po:
            raise NotFound("payout")
        pay = self.conn.execute("SELECT merchant_id FROM payables WHERE payable_id=?", (po["payable_id"],)).fetchone()
        if pay and pay["merchant_id"] and actor["role"] != "platform_compliance":
            self._require_merchant_member(actor, pay["merchant_id"], {"owner", "finance"})
        if actor["user_id"] == po["requested_by"]:
            raise Forbidden("maker cannot approve own payout")
        move(po["status"], "APPROVED", PAYOUT_TRANSITIONS, "payout_status")
        try:
            self.conn.execute(
                "UPDATE payouts SET status=?, approved_by=? WHERE payout_id=?",
                ("APPROVED", actor["user_id"], payout_id),
            )
            self.conn.execute(
                """UPDATE approvals SET status='APPROVED', approved_by=?
                   WHERE resource_id=? AND status='PENDING'""",
                (actor["user_id"], payout_id),
            )
        except sqlite3.IntegrityError as e:
            raise Forbidden("maker cannot approve own payout") from e
        self.conn.commit()
        return dict(self.conn.execute("SELECT * FROM payouts WHERE payout_id=?", (payout_id,)).fetchone())

    # --- donations ---
    def create_campaign(self, actor: dict, title: str) -> dict:
        self._active_actor(actor)
        if not self.cfg.get("donations_enabled", False):
            raise Unprocessable("donation campaigns are not offered in Phase 10.2")
        raise Unprocessable("donation campaigns are not compiled in Phase 10.2")

    def donate(self, actor: dict, campaign_id: str, amount_minor: int) -> None:
        if not self.cfg.get("donations_enabled"):
            raise Unprocessable("donation money flow is disabled until classification memo")
        raise Unprocessable("donation money flow is disabled until classification memo")

    def post_donation_to_operating(self, actor: dict, amount_minor: int) -> None:
        raise LedgerError("donation cannot hit operating revenue")

    # --- recon ---
    def run_reconciliation(self, actor: dict, partner_position_minor: int, platform_liability_minor: int) -> dict:
        self._active_actor(actor)
        rbac.require(actor["role"], "recon.run")
        diff = partner_position_minor - platform_liability_minor
        status = "CLEAN" if diff == 0 else "BREAK"
        rid = sbx("rrun")
        self.conn.execute(
            """INSERT INTO reconciliation_runs(run_id,environment,partner_position_minor,platform_liability_minor,
               difference_minor,status,created_by) VALUES (?,?,?,?,?,?,?)""",
            (rid, self.env, partner_position_minor, platform_liability_minor, diff, status, actor["user_id"]),
        )
        if diff != 0:
            self.conn.execute(
                """INSERT INTO reconciliation_breaks(break_id,run_id,description,amount_minor,status)
                   VALUES (?,?,?,?,?)""",
                (sbx("brk"), rid, "position mismatch", diff, "OPEN"),
            )
            for code in ("pause_payment_initiation", "pause_payouts", "pause_partner_rail"):
                self.conn.execute(
                    "UPDATE kill_switches SET active=1, reason=?, activated_by=? WHERE code=?",
                    ("recon break", actor["user_id"], code),
                )
                self.audit(actor, "kill_switch", resource_id=code, after="1", reason="recon break")
        self.conn.commit()
        return {"run_id": rid, "status": status, "difference_minor": diff}
