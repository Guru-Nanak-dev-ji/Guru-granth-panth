"""Begampura Financial Network — Phase 10.2.1 Boot-Sealed Sandbox Core."""

__version__ = "10.2.1-sandbox"
LIVE_MONEY_ENABLED = False
