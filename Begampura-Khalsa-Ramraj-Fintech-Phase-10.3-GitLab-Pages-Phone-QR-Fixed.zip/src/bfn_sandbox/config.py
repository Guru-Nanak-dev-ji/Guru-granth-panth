"""Sealed sandbox configuration. Fail-closed on live money or production-class secrets."""

from __future__ import annotations

import json
import os
import re
from pathlib import Path

from .errors import BootError

ALLOWED_ENVIRONMENTS = frozenset({"local", "sandbox"})

FORBIDDEN_SECRET_PATTERNS = [
    re.compile(r"sk_live_", re.I),
    re.compile(r"rk_live_", re.I),
    re.compile(r"whsec_live", re.I),
    re.compile(r"pk_live_", re.I),
    re.compile(r"live_secret", re.I),
    re.compile(r"prod[_-]?payment", re.I),
    re.compile(r"production[_-]?dsn", re.I),
]

FORBIDDEN_ENV_KEYS = {
    "STRIPE_LIVE_SECRET_KEY",
    "STRIPE_SECRET_KEY",
    "ADYEN_LIVE_KEY",
    "LIVE_PAYMENT_KEY",
    "PRODUCTION_DATABASE_URL",
}

SEALED_FALSE_FLAGS = (
    "live_money_enabled",
    "donations_enabled",
    "crowdfunding_offered",
    "cards_execution",
    "fx_execution",
    "remittance_execution",
    "kdn_production_write",
)

SEALED_ENV_FLAGS = {
    "LIVE_MONEY_ENABLED": "live_money_enabled",
    "DONATIONS_ENABLED": "donations_enabled",
    "CROWDFUNDING_OFFERED": "crowdfunding_offered",
    "CARDS_EXECUTION": "cards_execution",
    "FX_EXECUTION": "fx_execution",
    "REMITTANCE_EXECUTION": "remittance_execution",
    "KDN_PRODUCTION_WRITE": "kdn_production_write",
}


def default_config() -> dict:
    return {
        "phase": 10,
        "hardening_patch": "10.2.1",
        "working_name": "Begampura Khalsa Ramraj Financial Network",
        "live_money_enabled": False,
        "environment": "sandbox",
        "donations_enabled": False,
        "crowdfunding_offered": False,
        "cards_execution": False,
        "fx_execution": False,
        "remittance_execution": False,
        "kdn_production_write": False,
        "currency": "CAD",
        "webhook": {
            "clock_skew_seconds": 300,
            "active_kid": "sbx_whsec_1",
            "rotated_kid": "sbx_whsec_0",
        },
        "public_claims": {
            "uses_word_bank": False,
            "licensed_bank": False,
        },
    }


def load_config(path: str | None = None) -> dict:
    cfg = default_config()
    if path:
        loaded = json.loads(Path(path).read_text(encoding="utf-8"))
        cfg.update(loaded)
        if "webhook" in loaded and isinstance(loaded["webhook"], dict):
            cfg["webhook"] = {**default_config()["webhook"], **loaded["webhook"]}
    return cfg


def _scan_mapping(mapping: dict) -> None:
    """Recursively reject production-class credentials anywhere in a mapping tree."""
    for key, value in mapping.items():
        if value is None:
            continue
        if isinstance(value, dict):
            _scan_mapping(value)
            continue
        if isinstance(value, (list, tuple, set)):
            for item in value:
                if isinstance(item, dict):
                    _scan_mapping(item)
                elif item is not None:
                    _scan_mapping({str(key): item})
            continue

        text = str(value)
        normalized_key = str(key).upper()
        if normalized_key in FORBIDDEN_ENV_KEYS:
            raise BootError(f"production-class credential key present: {key}")
        for pat in FORBIDDEN_SECRET_PATTERNS:
            if pat.search(text):
                raise BootError(f"production-class credential pattern in {key}")
        if normalized_key in {"DATABASE_URL", "DSN"} and "prod" in text.lower():
            raise BootError("production-class DSN refused in sandbox boot")


def _sealed_false(value: object) -> bool:
    """Return True only for explicit disabled spellings; every other value is unsafe."""
    if value is False or value is None:
        return True
    if isinstance(value, int) and not isinstance(value, bool):
        return value == 0
    if isinstance(value, str):
        return value.strip().lower() in {"", "0", "false", "no", "off"}
    return False


def assert_boot_safe(cfg: dict | None = None) -> dict:
    cfg = cfg or load_config(os.environ.get("BFN_CONFIG"))

    # Config-file values are deny-by-default: only explicit false spellings are safe.
    for name in SEALED_FALSE_FLAGS:
        if not _sealed_false(cfg.get(name)):
            label = "LIVE_MONEY_ENABLED" if name == "live_money_enabled" else name
            raise BootError(f"{label} must be explicitly false in Phase 10.2.1")

    # Environment overrides are held to the same deny-by-default rule. An absent
    # variable is safe; if present, it must be an explicit false spelling.
    for env_name in SEALED_ENV_FLAGS:
        env_value = os.environ.get(env_name)
        if env_value is not None and not _sealed_false(env_value):
            raise BootError(f"{env_name} environment override must be explicitly false")

    env = cfg.get("environment")
    if env not in ALLOWED_ENVIRONMENTS:
        raise BootError(f"environment {env!r} is not local|sandbox")
    if cfg.get("public_claims", {}).get("uses_word_bank") or cfg.get("public_claims", {}).get(
        "licensed_bank"
    ):
        raise BootError("public bank claim is forbidden")

    # Scan the complete environment and complete nested config, not selected leaves.
    _scan_mapping(os.environ)
    _scan_mapping(cfg)
    return cfg
