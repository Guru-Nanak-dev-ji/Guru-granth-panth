class BfnError(Exception):
    status_code = 400
    code = "BFN_ERROR"


class BootError(BfnError):
    status_code = 500
    code = "BOOT_FAILURE"


class AuthError(BfnError):
    status_code = 401
    code = "UNAUTHENTICATED"


class Forbidden(BfnError):
    status_code = 403
    code = "FORBIDDEN"


class NotFound(BfnError):
    status_code = 404
    code = "NOT_FOUND"


class Conflict(BfnError):
    status_code = 409
    code = "CONFLICT"


class IdempotencyMismatch(BfnError):
    status_code = 409
    code = "IDEMPOTENCY_KEY_REUSED_WITH_DIFFERENT_BODY"


class Unprocessable(BfnError):
    status_code = 422
    code = "UNPROCESSABLE"


class KillSwitchActive(BfnError):
    status_code = 422
    code = "KILL_SWITCH_ACTIVE"


class LedgerError(BfnError):
    status_code = 422
    code = "LEDGER_INVARIANT"
