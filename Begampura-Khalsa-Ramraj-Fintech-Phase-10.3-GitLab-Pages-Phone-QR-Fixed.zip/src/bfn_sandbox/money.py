from __future__ import annotations

from .errors import Unprocessable

CURRENCY = "CAD"


def minor(amount_minor: int) -> int:
    if not isinstance(amount_minor, int) or isinstance(amount_minor, bool):
        raise Unprocessable("amount_minor must be an integer CAD cent")
    if amount_minor <= 0:
        raise Unprocessable("amount_minor must be > 0")
    return amount_minor


def require_cad(currency: str) -> str:
    if currency != CURRENCY:
        raise Unprocessable("Phase 10 sandbox is CAD minor units only")
    return currency
