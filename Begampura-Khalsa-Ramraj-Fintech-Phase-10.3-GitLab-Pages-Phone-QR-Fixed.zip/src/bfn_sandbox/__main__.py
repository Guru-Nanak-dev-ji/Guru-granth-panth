from .boot import main

raise SystemExit(main())
