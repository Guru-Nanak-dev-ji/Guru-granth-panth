(() => {
  'use strict';
  const $ = (s) => document.querySelector(s), KEY = 'bkr_phase_10_3_demo_state', stateBox = $('#state');
  let demo = null;
  const id = (prefix) => { const b = new Uint8Array(8); crypto.getRandomValues(b); return `${prefix}_${[...b].map((x) => x.toString(16).padStart(2, '0')).join('')}`; };
  const money = (n) => new Intl.NumberFormat('en-CA', {style:'currency', currency:'CAD'}).format(n / 100);
  const esc = (v) => String(v).replace(/[&<>'\"]/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','\"':'&quot;'}[c]));
  const save = () => localStorage.setItem(KEY, JSON.stringify(demo));
  function makeQr(text) {
    const qr = new window.BKRQRCode(-1, 2); qr.addData(text); qr.make();
    const count = qr.getModuleCount(), quiet = 4; let path = '';
    for (let r = 0; r < count; r += 1) for (let c = 0; c < count; c += 1) if (qr.isDark(r, c)) path += `M${c+quiet} ${r+quiet}h1v1h-1z`;
    const size = count + quiet * 2;
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${size} ${size}" aria-label="Sandbox payment QR"><rect width="100%" height="100%" fill="white"/><path d="${path}" fill="#111827"/></svg>`;
  }
  function render() {
    if (!demo) { stateBox.textContent = 'No demo payment yet.'; return; }
    $('#qrCard').classList.remove('hidden'); $('#flowCard').classList.remove('hidden');
    $('#qrRef').textContent = `${demo.intent_id} • expires ${new Date(demo.expires_at).toLocaleTimeString()}`; $('#qr').innerHTML = makeQr(demo.qr_payload); stateBox.textContent = JSON.stringify(demo, null, 2);
    const settled = demo.status === 'SETTLED', clean = demo.reconciliation_status === 'CLEAN';
    $('#steps').innerHTML = [['Intent',true],['QR',true],['Settled',settled],['Reconciled',clean]].map(([x,y]) => `<div class="step ${y?'done':''}">${y?'✓':'○'} ${x}</div>`).join('');
    $('#pay').disabled = settled; $('#pay').textContent = settled ? '✓ Demo payment SETTLED' : '📱 इसी फोन पर Pay Demo करें'; $('#payout').disabled = !settled || demo.payout_status === 'APPROVED'; $('#reconcile').disabled = !settled || clean;
    if (settled) {
      $('#receiptCard').classList.remove('hidden');
      const rows = [['Merchant',demo.merchant],['Amount',money(demo.amount_minor)],['Status',demo.status],['Intent ID',demo.intent_id],['Receipt ID',demo.receipt_id],['Time',new Date(demo.settled_at).toLocaleString()]];
      $('#receipt').innerHTML = rows.map(([k,v]) => `<div><dt>${esc(k)}</dt><dd>${esc(v)}</dd></div>`).join('');
    }
  }
  $('#create').addEventListener('click', () => {
    const merchant = $('#merchant').value.trim(), amount = Number($('#amount').value);
    if (!merchant) return alert('Merchant name लिखें।');
    if (!Number.isFinite(amount) || amount < 1 || amount > 10000) return alert('Demo amount 1 से 10,000 CAD के बीच रखें।');
    const amountMinor = Math.round(amount * 100), intentId = id('pi_demo'), expires = Date.now() + 300000;
    demo = {environment:'sandbox',live_money_enabled:false,payment_rail_connected:false,merchant,amount_minor:amountMinor,currency:'CAD',intent_id:intentId,status:'INITIATED',created_at:new Date().toISOString(),expires_at:new Date(expires).toISOString(),qr_payload:`bkr-sandbox://pay?intent=${encodeURIComponent(intentId)}&amount_minor=${amountMinor}&currency=CAD`,payout_status:null,reconciliation_status:null,warning:'SANDBOX — no real payment is created'};
    save(); render(); $('#qrCard').scrollIntoView({behavior:'smooth',block:'start'});
  });
  $('#pay').addEventListener('click', () => {
    if (!demo || demo.status === 'SETTLED') return;
    if (Date.now() > Date.parse(demo.expires_at)) { demo.status = 'EXPIRED'; save(); render(); return alert('QR expire हो गया। नया Demo Payment बनाएँ।'); }
    demo.status = 'SETTLED'; demo.settled_at = new Date().toISOString(); demo.receipt_id = id('rcpt_demo'); save(); render(); $('#receiptCard').scrollIntoView({behavior:'smooth',block:'start'});
  });
  $('#payout').addEventListener('click', () => { demo.payout_status = 'APPROVED'; save(); render(); });
  $('#reconcile').addEventListener('click', () => { demo.reconciliation_status = 'CLEAN'; save(); render(); });
  $('#newPayment').addEventListener('click', () => { demo=null; localStorage.removeItem(KEY); $('#qrCard').classList.add('hidden'); $('#flowCard').classList.add('hidden'); $('#receiptCard').classList.add('hidden'); render(); window.scrollTo({top:0,behavior:'smooth'}); });
  try { demo = JSON.parse(localStorage.getItem(KEY)); } catch (_) { demo = null; } render();
})();
