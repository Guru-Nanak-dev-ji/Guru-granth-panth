const QRCode = require('./vendor');
const value = process.argv[2] || '';
const qr = new QRCode(-1, 2);
qr.addData(value);
qr.make();
const count = qr.getModuleCount();
const quiet = 4, scale = 8, size = (count + quiet * 2) * scale;
let path = '';
for (let r = 0; r < count; r++) for (let c = 0; c < count; c++) {
  if (qr.isDark(r, c)) path += `M${(c+quiet)*scale} ${(r+quiet)*scale}h${scale}v${scale}h-${scale}z`;
}
process.stdout.write(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${size} ${size}" width="${size}" height="${size}" role="img" aria-label="Sandbox payment QR"><rect width="100%" height="100%" fill="white"/><path d="${path}" fill="#111827"/></svg>`);
