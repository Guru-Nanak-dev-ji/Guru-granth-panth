# Webhooks — Phase 10.2.1

Only `mock_partner` exists.

1. Require a stored ACTIVE actor with `webhook.ingest` (`partner_tech` externally; `system` only for the internal mock adapter helper).
2. Parse `X-BFN-Signature`; exactly one `t=` is required, one or more `v1=` values are allowed for key rotation.
3. Enforce clock skew (default 300 seconds).
4. Verify HMAC-SHA256 over `"{timestamp}." + raw_body` before parsing attacker-controlled event IDs.
5. Validate JSON object, partner source, external event ID, event type, payment intent ID, and referenced intent.
6. Only then reserve replay identity `(environment, partner_source, external_event_id)`.
7. Same verified body replays safely; same ID with a different verified body is conflict.
8. SETTLED is applied only from a legal settlement state; late events cannot move SETTLED backward.

Rejected unauthenticated/invalid webhook input does not reserve replay identity. Replay identities are retained for the life of the sandbox store; the unused `replay_ttl_seconds` claim was removed in Phase 10.2.1.
