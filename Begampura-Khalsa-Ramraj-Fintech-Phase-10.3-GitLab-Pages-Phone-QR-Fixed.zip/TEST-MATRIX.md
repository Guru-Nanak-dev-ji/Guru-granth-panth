# TEST-MATRIX — executable mapping

| Audit ID | File / test | Expected result |
|---|---|---|
| T-LED-01 | `tests/test_led.py::test_t_led_01_one_hundred_thousand_balanced_journals` | 100k journals, 0 unbalanced |
| T-LED-02 | `test_t_led_02_update_delete_posted_entries_fail` | UPDATE/DELETE posted entry raises LedgerError |
| T-LED-03 | `test_t_led_03_reversal_creates_new_journal` | new journal, original sealed, reverses_journal_id set |
| T-LED-unbalanced | `test_unbalanced_journal_rejected` | 10 vs 9 rejected |
| T-DON-op | `test_donation_cannot_hit_operating` | operating revenue reject |
| T-IDP-01 | `tests/test_idp.py::test_t_idp_01_same_key_same_body_same_intent` | one intent |
| T-IDP-02 | `test_t_idp_02_same_key_changed_amount_409` | status_code 409 |
| T-IDP-03 | `test_t_idp_03_same_raw_key_two_principals` | two intents |
| T-WH-01 | `tests/test_wh.py::test_t_wh_01_valid_signature_one_transition` | SETTLED after partner event |
| T-WH-02 | `test_t_wh_02_replay_no_second_journal` | REPLAY, journal count unchanged |
| T-WH-03 | `test_t_wh_03_bad_signature_cannot_settle` | not SETTLED |
| T-WH-04 | `test_t_wh_04_timestamp_skew_rejected` | Unprocessable skew |
| T-WH-05 | `test_t_wh_05_out_of_order_cannot_move_settled_backward` | stays SETTLED |
| T-WH-rot | `test_rotated_key_still_accepted` | rotated secret works |
| T-PAY-01 | `tests/test_pay.py::test_t_pay_01_frontend_success_cannot_settle` | remains POSTED |
| T-PAY-02 | `test_t_pay_02_qr_reuse_rejected` | consumed |
| T-PAY-03 | `test_t_pay_03_dynamic_qr_expiry` | expired |
| T-PAY-04 | `test_t_pay_04_tampered_qr_amount_server_wins` | server amount |
| T-INV | `test_invoice_paid_cannot_become_overdue` | 422 |
| T-PO-01 | `test_t_po_01_payout_exceeds_eligible` | 422 |
| T-PO-02 | `test_t_po_02_payout_from_unsettled_rejected` | 422 |
| T-PO-04 | `test_t_po_04_maker_cannot_approve` | 403 |
| T-PO-ok | `test_finance_can_approve_owner_payout` | different users |
| T-DON | `test_donations_feature_off` | 422 |
| T-AUTH-01 | `tests/test_auth.py::test_t_auth_01_cashier_payout_403` | 403 |
| T-AUTH-03 | `test_t_auth_03_owner_cannot_flip_live` | stays SANDBOX_ACTIVE |
| T-AI | `test_ai_has_no_money_permissions` | all False |
| T-ISO | `tests/test_iso.py` | env, sbx_, CAD, books, secrets |
| T-LIVE | `test_t_live_flag_true_boot_failure` | BootError |
| T-SEC-01 | `test_t_sec_01_production_credential_boot_failure` | BootError |
| T-KILL-01 | `tests/test_kill.py::test_t_kill_01_blocks_mutations_allows_reads` | create blocked, GET works |
| T-RECON | `test_recon_break_freezes_outbound` | BREAK + kill |


## Phase 10.1 hardening regression tests (retained)

| Audit ID | File / test | Expected result |
|---|---|---|
| T-WH-06 | `test_t_wh_06_invalid_signature_cannot_poison_external_event_id` | bad signature reserves nothing; valid retry settles |
| T-WH-07 | `test_t_wh_07_unknown_event_type_is_clean_422` | controlled 422 |
| T-WH-08 | `test_t_wh_08_missing_external_event_id_is_clean_422` | controlled 422 |
| T-WH-09 | `test_t_wh_09_missing_payment_intent_id_is_clean_422` | controlled 422 |
| T-WH-10 | `test_t_wh_10_malformed_timestamp_is_clean_422` | controlled 422 |
| T-WH-11 | `test_t_wh_11_same_external_id_different_verified_payload_conflicts` | 409 conflict |
| T-AUTH-04 | `test_t_auth_04_support_cannot_create_merchant` | 403 |
| T-AUTH-05 | `test_t_auth_05_cross_merchant_intent_blocked` | 403 |
| T-AUTH-06 | `test_t_auth_06_nonmember_cashier_cannot_issue_qr` | 403 |
| T-AUTH-07 | `test_t_auth_07_cross_merchant_invoice_blocked` | 403 |
| T-AUTH-08 | `test_t_auth_08_cross_merchant_payout_blocked` | 403 |
| T-AUTH-09 | `test_t_auth_09_revoked_member_cannot_replay_idempotent_payout` | 403 before replay |
| T-AUTH-10 | `test_t_auth_10_forged_actor_role_rejected` | 403 |
| T-AUTH-11 | `test_t_auth_11_platform_compliance_can_be_independent_payout_checker` | independent checker approved |
| T-IDP-04 | `test_t_idp_04_merchant_creation_requires_key_and_replays` | key required; replay same merchant |
| T-IDP-05 | `test_t_idp_05_qr_creation_requires_key_and_replays` | key required; replay same QR |
| T-IDP-06 | `test_t_idp_06_invoice_creation_requires_key_and_replays` | key required; replay same invoice |
| T-AUTH-12 | `test_t_auth_12_forged_admin_cannot_flip_kill_switch` | forged role denied |
| T-AUTH-13 | `test_t_auth_13_forged_compliance_cannot_run_reconciliation` | forged role denied |
| T-AUTH-14 | `test_t_auth_14_membership_role_cannot_escalate_stored_user_role` | role drift denied |


## Phase 10.2 red-team regressions

`tests/test_redteam_10_2.py` covers sealed-flag boot, strict amount types, controlled malformed input, required merchant binding, idempotency key types, money-helper RBAC, recon full outbound freeze, privileged-role minting, authenticated webhook actor, duplicate webhook timestamps, invoice transition auth, donation NOT_OFFERED, and immutable DB feature flags.

## Phase 10.2.1 boot-seal regressions

- unknown/truthy `LIVE_MONEY_ENABLED` environment spellings => BootError
- all sealed execution environment overrides => BootError unless explicitly false
- explicit false environment spellings remain bootable
- nested production-class secret pattern => BootError
- deeply nested list secret pattern => BootError
