# SECURITY-NOTES — Phase 10.2.1

## Trust boundary

The executable in this ZIP is an in-process sandbox engine. There is no production HTTP listener. OpenAPI is a reference adapter contract; any future transport must add bearer authentication while retaining the engine's stored-user RBAC and merchant-membership checks.

## Boot sealing

`live_money_enabled`, `donations_enabled`, `crowdfunding_offered`, `cards_execution`, `fx_execution`, `remittance_execution`, and `kdn_production_write` must all evaluate false. Common truthy string/integer forms fail boot. Production-like secrets, production DSNs, and public bank claims fail boot.

## Identity / authorization

- Caller-supplied roles are checked against the stored ACTIVE user record.
- Public `create_user` is limited to non-platform sandbox roles.
- Platform/system/partner identities are bootstrap-only and are not exposed by the OpenAPI contract.
- Merchant mutations require exact ACTIVE membership and role equality.
- `system` does not bypass merchant membership.
- Payment authorize/post and pending-settlement steps require explicit permissions.
- Payout maker cannot approve the same payout; platform compliance may be an independent checker.

## Money input

- CAD only.
- `amount_minor` must be Python integer cents and must not be bool, float, or string.
- Payment intents require `merchant_id` and currency explicitly.
- Unknown payer/foreign-key inputs are converted to controlled `Unprocessable` errors.

## Reconciliation

Any non-zero reconciliation difference is BREAK and activates all outbound safety switches: payment initiation, payouts, and partner rail.

## Donations and uncompiled operations

Donation/crowdfunding flags are sealed false and campaign creation returns NOT_OFFERED. Refund, dispute, and payment-intent cancel execution are not advertised in the Phase 10.2.1 OpenAPI.
