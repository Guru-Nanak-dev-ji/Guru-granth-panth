# Begampura Khalsa Ramraj Financial Network — Phase 10.2.1 Boot-Sealed Sandbox Core

**Public working name:** Begampura Khalsa Ramraj Financial Network  
**Not a bank / PSP / live payment service.**  
**`LIVE_MONEY_ENABLED=false`** and all sealed execution flags must remain false.

Phase 10.2.1 is a security-only response to the independent Phase 10.1 and Phase 10.2 red-team FAIL findings. It adds no Phase 11 product surface and enables no real-money rail.

## Scope

Compiled sandbox runtime:

- SQLite in-process engine and PostgreSQL reference schema
- CAD integer minor-unit ledger, sealed journals, reversals
- merchant-bound payment intents, QR, invoices, payables, payouts
- stored-user RBAC + exact ACTIVE merchant membership
- maker ≠ checker payout approval
- mock-partner HMAC webhook ingress with explicit authenticated partner actor
- kill switches, reconciliation, audit

Explicitly not compiled/offered:

- live money, cards, FX, remittance, KDN production writes
- donation/crowdfunding execution or campaign creation
- refund/dispute/cancel execution
- production HTTP listener, TLS termination, DNS, production credentials
- Phase 11

## Fail-closed boot

These flags are sealed false. Config values and matching environment overrides are deny-by-default: when supplied, only explicit false spellings (`false`, `0`, `no`, `off`, or empty where applicable) are accepted; every other value refuses boot:

```text
LIVE_MONEY_ENABLED=false
DONATIONS_ENABLED=false
CROWDFUNDING_OFFERED=false
CARDS_EXECUTION=false
FX_EXECUTION=false
REMITTANCE_EXECUTION=false
KDN_PRODUCTION_WRITE=false
```

Production-style payment secrets and production environments are also rejected at boot.

## Run

```bash
cd begampura-fn-phase10.2.1-boot-sealed-sandbox-core
PYTHONPATH=src python3 -m bfn_sandbox.boot config/sandbox.json
PYTHONPATH=src python3 -m pytest tests -q
```

Boot must print:

```text
BFN Phase 10.2.1 boot-sealed sandbox boot OK; LIVE_MONEY_ENABLED=false
```

## Phase 10.2 / 10.2.1 security delta

- All sealed execution flags fail boot unless explicitly false, including config values and environment overrides.
- Production-class credential patterns are scanned recursively across nested configuration mappings/lists.
- Payment intent requires a non-empty `merchant_id`, exact ACTIVE membership, strict integer CAD cents, and controlled 422-style validation.
- `bool`, float, numeric string, missing amount, and unknown payer are rejected without raw Python/SQLite errors.
- Idempotency keys must be non-empty strings.
- `authorize_and_post` and `mark_pending_settlement` have explicit permissions and merchant-role limits.
- Public `create_user` cannot mint platform/system/partner privileged roles; privileged identities are bootstrap-only test fixtures.
- `system` no longer bypasses merchant membership.
- Webhook ingest requires a stored actor with `webhook.ingest`; duplicate `t=` signature fields are rejected.
- Reconciliation BREAK activates `pause_payment_initiation`, `pause_payouts`, and `pause_partner_rail`.
- Manual invoice transitions require actor + RBAC + merchant membership and are limited to offered manual states.
- Donation campaign creation is NOT_OFFERED while the donation flag is sealed false.
- SQLite user-role constraints now mirror PostgreSQL; database feature-flag rows cannot be enabled.
- OpenAPI no longer advertises uncompiled refund/dispute/cancel/donation operations and explicitly states that no HTTP listener is compiled.

## Release status

This is a **Phase 10.2.1 red-team candidate**, not the final freeze. Run the included suite, then give the ZIP to Grok for an independent post-patch attack using `GROK-RED-TEAM-HANDOFF.md`.

**Phase 11 remains closed.**

## Phone-friendly demo add-on

This package now also includes a local browser demo under `web/` and a standard-library HTTP wrapper at `bfn_sandbox.demo_server`. It renders a real QR, supports same-phone scan simulation, and exercises the existing server-authoritative sandbox flow through settlement, maker/checker payout approval, and reconciliation. See `RUN-DEMO.md` and `DEMO-VERIFY-RESULTS.txt`.
