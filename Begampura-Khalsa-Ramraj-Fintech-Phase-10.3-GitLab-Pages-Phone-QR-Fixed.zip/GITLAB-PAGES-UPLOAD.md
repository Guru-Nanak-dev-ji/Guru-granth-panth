# GitLab Pages — phone upload

Upload this ZIP's complete contents into the existing GitLab project's root and commit to the default branch. The included `.gitlab-ci.yml` publishes `web/` as the Pages site.

After the pipeline passes, open the existing Pages URL and refresh once. The heading must read **Phone QR Sandbox**. Test: create an intent, confirm the QR, tap **इसी फोन पर Pay Demo करें**, and confirm the **SETTLED** demo receipt. No real money rail or bank connection exists.
