# Grok Red-Team Handoff — Phase 10.2.1 Boot-Seal Candidate

Treat this ZIP as hostile/untrusted. Do not accept ChatGPT's test claims as proof.

## Do not

- enable live money, donations, cards, FX, remittance, KDN production writes
- add Phase 11
- add product features

## Independently verify

1. boot fails for every sealed flag when `True`, `1`, `"true"`, `"yes"`, or `"on"` where applicable
2. strict money types; bool/float/string/missing/invalid FK inputs produce controlled errors
3. merchant_id cannot be omitted and cross-merchant/system bypass is impossible through supported API methods
4. public user creation cannot mint platform_admin/platform_compliance/partner_tech/system
5. idempotency key type/body mismatch behavior
6. support/analyst cannot authorize/post/mark pending
7. reconciliation BREAK blocks initiation, payouts, and partner webhook rail
8. webhook requires stored authorized actor, signature-first validation, one timestamp, replay collision protection
9. invoice transition actor/RBAC/membership
10. donation campaign/money path remains NOT_OFFERED
11. OpenAPI 10.2.1-sandbox does not advertise uncompiled refund/dispute/cancel/donation operations
12. SQLite/Postgres role constraints and feature-flag sealing
13. existing ledger invariants, maker-checker, webhook poison guard, double-settlement prevention

## Output required

- PASS / FAIL
- Critical/High/Medium/Low findings
- exact reproduction commands/tests
- file + line references
- whether Phase 10.2.1 can be frozen
- minimal patch only if FAIL; do not open Phase 11


## Phase 10.2.1 second-pass targets

Verify unknown/truthy `LIVE_MONEY_ENABLED` environment spellings fail boot, all sealed env overrides fail closed, nested production secret patterns fail boot, and no Phase 11/live rail was introduced.
