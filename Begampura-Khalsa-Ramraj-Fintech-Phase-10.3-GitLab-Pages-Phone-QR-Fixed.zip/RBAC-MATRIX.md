# RBAC-MATRIX — Phase 10.2.1

`LIVE_MONEY_ENABLED` is not a permission. Nobody — including `platform_admin` and `ai_assistant` — can flip it through RBAC.

| Permission | customer | cashier | finance | owner | support | analyst | plat. support | plat. compliance | plat. admin | partner_tech | system | ai_assistant |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| intent.create / authorize / mark pending | | Y | Y | Y | | | | | | | | |
| intent.read.own | Y | | | | | | | | | | | |
| intent.read.merchant | | Y | Y | Y | Y | Y | Y | Y | | | | |
| intent.cancel | | | | Y | | | | | | | | |
| qr.issue / resolve | | Y | | Y | | | | | | | | |
| invoice.create / send | | | Y | Y | | | | | | | | |
| refund.initiate | | | Y | Y | | | | | | | | |
| payout.initiate | | | Y | Y | | | | | | | | |
| payout.approve | | | Y* | Y* | | | | Y* | | | | |
| destination.change | | | | Y | | | | | | | | |
| pi.read.limited | | | | | Y | | Y | | | | | |
| pi.read.full | | | | | | | | Y | | | | |
| metrics.read.store | | Y | Y | Y | Y | Y | | | | | | |
| metrics.read.ops | | | | | | | Y | Y | Y | | | |
| ledger.read | | | Y | Y | | Y | | Y | Y | | Y | |
| approval.decide | | | | | | | | Y | | | | |
| recon.run | | | | | | | | Y | Y | | Y | |
| kill.switch | | | | | | | | | Y | | | |
| audit.read | | | | | | | | Y | Y | | | |
| webhook.ingest | | | | | | | | | | Y | Y | |
| enact / settle without partner | | | | | | | | | | | | |
| live.money.enable | | | | | | | | | | | | |

\* Approve is allowed only when `approved_by ≠ requested_by`.

AI may draft text outside this process. AI may not create intents, approve, settle, payout, or enable live money.


Phase 10.2.1 object-level rule: role permission alone is insufficient for merchant-scoped mutations. The actor must also have an `ACTIVE` membership on that exact merchant, except `platform_compliance` acting as the documented independent payout checker.
