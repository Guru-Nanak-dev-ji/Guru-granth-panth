# Phase 10 phone-friendly sandbox demo

This demo wraps the existing boot-sealed engine; it does not add a live rail.

```bash
PYTHONPATH=src python3 -m bfn_sandbox.demo_server
```

Open `http://127.0.0.1:8080`. The demo supports: persistent server intent → signed dynamic QR → same-phone scan simulation → authorization/ledger post → verified mock-partner HMAC settlement → maker/checker payout approval → reconciliation.

Dependency-free smoke test:

```bash
PYTHONPATH=src python3 tests/demo_smoke.py
```

`LIVE_MONEY_ENABLED=false` remains mandatory. The browser never settles an intent; settlement occurs only through the mock-partner signed webhook path.
