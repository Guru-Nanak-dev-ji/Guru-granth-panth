/* Mechanical CommonJS-to-browser packer for the vendored MIT QR implementation. */
const fs = require('fs'), path = require('path');
const root = path.resolve(__dirname, '..', 'web', 'vendor'), output = path.resolve(__dirname, '..', 'web', 'qr-browser.js');
const names = ['QRMode','QRErrorCorrectLevel','QRMaskPattern','QRMath','QRPolynomial','QRBitBuffer','QR8bitByte','QRRSBlock','QRUtil','index'];
const modules = names.map((name) => `${JSON.stringify('./'+name)}:function(require,module,exports){\n${fs.readFileSync(path.join(root, name+'.js'),'utf8')}\n}`).join(',\n');
fs.writeFileSync(output, `(function(g){'use strict';var M={${modules}},C={};function R(n){if(n==='./vendor')n='./index';if(!M[n])throw Error('QR module not found: '+n);if(!C[n]){var m=C[n]={exports:{}};M[n](R,m,m.exports)}return C[n].exports}g.BKRQRCode=R('./index')})(window);\n`);
