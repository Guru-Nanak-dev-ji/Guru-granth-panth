-- Begampura Khalsa Ramraj Financial Network
-- Phase 10.2 Fail-Closed Hardened Sandbox Core — PostgreSQL reference migration
-- LIVE_MONEY_ENABLED=false is enforced in application boot, not by flipping rows.
-- Environment is locked to local|sandbox. LIVE_ACTIVE merchant/campaign states are rejected.

BEGIN;

CREATE TABLE environments_allowed (
  environment TEXT PRIMARY KEY CHECK (environment IN ('local', 'sandbox'))
);
INSERT INTO environments_allowed (environment) VALUES ('local'), ('sandbox');

-- ---------------------------------------------------------------------------
-- Users / RBAC
-- ---------------------------------------------------------------------------

CREATE TABLE users (
  user_id TEXT PRIMARY KEY CHECK (user_id LIKE 'sbx_%'),
  environment TEXT NOT NULL REFERENCES environments_allowed(environment),
  handle TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN (
    'customer','cashier','finance','owner','support','analyst',
    'platform_support','platform_compliance','platform_admin',
    'partner_tech','system','ai_assistant'
  )),
  status TEXT NOT NULL CHECK (status IN ('ACTIVE','DISABLED')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (environment, handle)
);

CREATE TABLE permissions (
  permission_code TEXT PRIMARY KEY,
  description TEXT NOT NULL
);

CREATE TABLE role_permissions (
  role TEXT NOT NULL,
  permission_code TEXT NOT NULL REFERENCES permissions(permission_code),
  PRIMARY KEY (role, permission_code)
);

CREATE TABLE merchants (
  merchant_id TEXT PRIMARY KEY CHECK (merchant_id LIKE 'sbx_%'),
  environment TEXT NOT NULL REFERENCES environments_allowed(environment),
  display_name TEXT NOT NULL,
  legal_name TEXT,
  status TEXT NOT NULL CHECK (status IN (
    'DRAFT','ONBOARDING','REVIEW_REQUIRED','SANDBOX_ACTIVE','LIMITED','SUSPENDED','CLOSED'
  )),
  -- LIVE_PENDING and LIVE_ACTIVE are intentionally absent: transition is impossible.
  risk_tier TEXT NOT NULL CHECK (risk_tier IN ('S0','L1','L2','L3','R')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE merchant_members (
  merchant_id TEXT NOT NULL REFERENCES merchants(merchant_id),
  user_id TEXT NOT NULL REFERENCES users(user_id),
  role TEXT NOT NULL CHECK (role IN ('owner','finance','cashier','support','analyst')),
  status TEXT NOT NULL CHECK (status IN ('ACTIVE','REVOKED')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (merchant_id, user_id)
);

-- ---------------------------------------------------------------------------
-- Ledger
-- ---------------------------------------------------------------------------

CREATE TABLE accounts (
  account_id TEXT PRIMARY KEY CHECK (account_id LIKE 'sbx_%'),
  environment TEXT NOT NULL REFERENCES environments_allowed(environment),
  currency TEXT NOT NULL CHECK (currency = 'CAD'),
  book TEXT NOT NULL CHECK (book IN ('SANDBOX_CASH','SANDBOX_POINTS')),
  owner_type TEXT NOT NULL CHECK (owner_type IN (
    'platform','merchant','customer','campaign','partner','system'
  )),
  owner_id TEXT,
  purpose TEXT NOT NULL CHECK (purpose IN (
    'operating','safeguarded_subledger','customer_wallet','merchant_receivable',
    'payable','fee','donation_restricted','hold','fx_clearing'
  )),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE ledger_journals (
  journal_id TEXT PRIMARY KEY CHECK (journal_id LIKE 'sbx_%'),
  environment TEXT NOT NULL REFERENCES environments_allowed(environment),
  source_type TEXT NOT NULL,
  source_id TEXT NOT NULL,
  sealed BOOLEAN NOT NULL DEFAULT FALSE,
  reverses_journal_id TEXT REFERENCES ledger_journals(journal_id),
  created_by TEXT NOT NULL REFERENCES users(user_id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (environment, source_type, source_id)
);

CREATE TABLE ledger_entries (
  entry_id TEXT PRIMARY KEY CHECK (entry_id LIKE 'sbx_%'),
  journal_id TEXT NOT NULL REFERENCES ledger_journals(journal_id),
  account_id TEXT NOT NULL REFERENCES accounts(account_id),
  currency TEXT NOT NULL CHECK (currency = 'CAD'),
  debit_minor INTEGER NOT NULL DEFAULT 0 CHECK (debit_minor >= 0),
  credit_minor INTEGER NOT NULL DEFAULT 0 CHECK (credit_minor >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (
    (debit_minor > 0 AND credit_minor = 0) OR
    (debit_minor = 0 AND credit_minor > 0)
  )
);

CREATE INDEX idx_ledger_entries_journal ON ledger_entries(journal_id);
CREATE INDEX idx_ledger_entries_account ON ledger_entries(account_id);

CREATE OR REPLACE FUNCTION forbid_mutate_sealed_entry() RETURNS trigger AS $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM ledger_journals j
    WHERE j.journal_id = COALESCE(OLD.journal_id, NEW.journal_id)
      AND j.sealed = TRUE
  ) THEN
    RAISE EXCEPTION 'posted ledger entries are immutable; create a reversal journal';
  END IF;
  IF TG_OP = 'DELETE' THEN
    RETURN OLD;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_ledger_entries_immutable
  BEFORE UPDATE OR DELETE ON ledger_entries
  FOR EACH ROW EXECUTE FUNCTION forbid_mutate_sealed_entry();

CREATE OR REPLACE FUNCTION forbid_unseal_or_edit_sealed_journal() RETURNS trigger AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'journals cannot be deleted';
  END IF;
  IF OLD.sealed = TRUE AND NEW.sealed = FALSE THEN
    RAISE EXCEPTION 'sealed journals cannot be unsealed';
  END IF;
  IF OLD.sealed = TRUE AND (
       NEW.source_type IS DISTINCT FROM OLD.source_type
    OR NEW.source_id IS DISTINCT FROM OLD.source_id
    OR NEW.reverses_journal_id IS DISTINCT FROM OLD.reverses_journal_id
    OR NEW.environment IS DISTINCT FROM OLD.environment
  ) THEN
    RAISE EXCEPTION 'sealed journals are immutable';
  END IF;
  IF NEW.sealed = TRUE AND OLD.sealed = FALSE THEN
    IF NOT EXISTS (SELECT 1 FROM ledger_entries e WHERE e.journal_id = NEW.journal_id) THEN
      RAISE EXCEPTION 'cannot seal empty journal';
    END IF;
    IF (SELECT COALESCE(SUM(debit_minor),0) FROM ledger_entries e WHERE e.journal_id = NEW.journal_id)
       <> (SELECT COALESCE(SUM(credit_minor),0) FROM ledger_entries e WHERE e.journal_id = NEW.journal_id) THEN
      RAISE EXCEPTION 'journal debit total must equal credit total';
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_ledger_journals_seal
  BEFORE UPDATE OR DELETE ON ledger_journals
  FOR EACH ROW EXECUTE FUNCTION forbid_unseal_or_edit_sealed_journal();

-- ---------------------------------------------------------------------------
-- Idempotency, partner events, webhooks
-- ---------------------------------------------------------------------------

CREATE TABLE idempotency_keys (
  idempotency_id TEXT PRIMARY KEY CHECK (idempotency_id LIKE 'sbx_%'),
  environment TEXT NOT NULL REFERENCES environments_allowed(environment),
  principal_id TEXT NOT NULL,
  route TEXT NOT NULL,
  idempotency_key TEXT NOT NULL,
  body_hash TEXT NOT NULL,
  resource_type TEXT,
  resource_id TEXT,
  status_code INTEGER NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (environment, principal_id, route, idempotency_key)
);

CREATE TABLE partner_events (
  partner_event_id TEXT PRIMARY KEY CHECK (partner_event_id LIKE 'sbx_%'),
  environment TEXT NOT NULL REFERENCES environments_allowed(environment),
  partner_source TEXT NOT NULL CHECK (partner_source = 'mock_partner'),
  external_event_id TEXT NOT NULL,
  event_type TEXT NOT NULL,
  payment_intent_id TEXT,
  payload_hash TEXT NOT NULL,
  verified BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (environment, partner_source, external_event_id)
);

CREATE TABLE webhook_receipts (
  receipt_id TEXT PRIMARY KEY CHECK (receipt_id LIKE 'sbx_%'),
  environment TEXT NOT NULL REFERENCES environments_allowed(environment),
  partner_source TEXT NOT NULL,
  external_event_id TEXT NOT NULL,
  signature_kid TEXT,
  timestamp_unix INTEGER NOT NULL,
  verified BOOLEAN NOT NULL,
  disposition TEXT NOT NULL CHECK (disposition IN (
    'ACCEPTED','REPLAY','REJECTED_SIGNATURE','REJECTED_SKEW','REJECTED_SCHEMA',
    'IGNORED_OUT_OF_ORDER','DEAD_LETTERED'
  )),
  raw_body_sha256 TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (environment, partner_source, external_event_id)
);

CREATE TABLE webhook_dlq (
  dlq_id TEXT PRIMARY KEY CHECK (dlq_id LIKE 'sbx_%'),
  receipt_id TEXT REFERENCES webhook_receipts(receipt_id),
  reason TEXT NOT NULL,
  retry_count INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE webhook_keys (
  kid TEXT PRIMARY KEY,
  environment TEXT NOT NULL REFERENCES environments_allowed(environment),
  secret_ref TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('ACTIVE','ROTATED','REVOKED')),
  activated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  rotated_at TIMESTAMPTZ
);

-- ---------------------------------------------------------------------------
-- Approvals / audit / kill switches / limits
-- ---------------------------------------------------------------------------

CREATE TABLE approvals (
  approval_id TEXT PRIMARY KEY CHECK (approval_id LIKE 'sbx_%'),
  environment TEXT NOT NULL REFERENCES environments_allowed(environment),
  resource_type TEXT NOT NULL,
  resource_id TEXT NOT NULL,
  action TEXT NOT NULL,
  requested_by TEXT NOT NULL REFERENCES users(user_id),
  approved_by TEXT REFERENCES users(user_id),
  status TEXT NOT NULL CHECK (status IN ('PENDING','APPROVED','REJECTED')),
  reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  decided_at TIMESTAMPTZ,
  CHECK (approved_by IS NULL OR approved_by <> requested_by)
);

CREATE TABLE audit_events (
  audit_id TEXT PRIMARY KEY CHECK (audit_id LIKE 'sbx_%'),
  environment TEXT NOT NULL REFERENCES environments_allowed(environment),
  actor_id TEXT,
  actor_role TEXT,
  action TEXT NOT NULL,
  resource_type TEXT,
  resource_id TEXT,
  before_state TEXT,
  after_state TEXT,
  reason_code TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_audit_created ON audit_events(created_at);

CREATE TABLE kill_switches (
  code TEXT PRIMARY KEY CHECK (code IN (
    'pause_new_registrations','pause_payment_initiation','pause_payouts',
    'pause_partner_rail','pause_donation_disbursement','global_money_off'
  )),
  environment TEXT NOT NULL REFERENCES environments_allowed(environment),
  active BOOLEAN NOT NULL DEFAULT FALSE,
  reason TEXT,
  activated_by TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

INSERT INTO kill_switches (code, environment, active) VALUES
  ('pause_new_registrations','sandbox', FALSE),
  ('pause_payment_initiation','sandbox', FALSE),
  ('pause_payouts','sandbox', FALSE),
  ('pause_partner_rail','sandbox', FALSE),
  ('pause_donation_disbursement','sandbox', FALSE),
  ('global_money_off','sandbox', FALSE);

CREATE TABLE limits (
  limit_id TEXT PRIMARY KEY CHECK (limit_id LIKE 'sbx_%'),
  environment TEXT NOT NULL REFERENCES environments_allowed(environment),
  subject_type TEXT NOT NULL,
  subject_id TEXT NOT NULL,
  limit_code TEXT NOT NULL,
  amount_minor INTEGER NOT NULL CHECK (amount_minor >= 0),
  currency TEXT NOT NULL CHECK (currency = 'CAD'),
  UNIQUE (environment, subject_type, subject_id, limit_code)
);

-- ---------------------------------------------------------------------------
-- Payments / QR / invoices
-- ---------------------------------------------------------------------------

CREATE TABLE payment_intents (
  payment_intent_id TEXT PRIMARY KEY CHECK (payment_intent_id LIKE 'sbx_%'),
  environment TEXT NOT NULL REFERENCES environments_allowed(environment),
  merchant_id TEXT REFERENCES merchants(merchant_id),
  payer_id TEXT REFERENCES users(user_id),
  amount_minor INTEGER NOT NULL CHECK (amount_minor > 0),
  currency TEXT NOT NULL CHECK (currency = 'CAD'),
  intent_status TEXT NOT NULL CHECK (intent_status IN (
    'CREATED','REQUIRES_ACTION','AUTHORIZED','CANCELLED','EXPIRED','FAILED'
  )),
  settlement_status TEXT NOT NULL CHECK (settlement_status IN (
    'NOT_APPLICABLE','POSTED','PENDING_SETTLEMENT','SETTLED','RETURNED'
  )),
  exception_status TEXT NOT NULL CHECK (exception_status IN (
    'NONE','REVERSED','REFUNDED','DISPUTED'
  )),
  purpose TEXT NOT NULL CHECK (purpose IN (
    'merchant_sale','invoice','payout_funding','marketplace_order','sandbox_transfer'
  )),
  -- donation purpose omitted from allowed money purposes while feature flag is off
  invoice_id TEXT,
  order_id TEXT,
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_intents_merchant ON payment_intents(merchant_id, created_at);

CREATE TABLE qr_tokens (
  qr_token_id TEXT PRIMARY KEY CHECK (qr_token_id LIKE 'sbx_%'),
  environment TEXT NOT NULL REFERENCES environments_allowed(environment),
  qr_kind TEXT NOT NULL CHECK (qr_kind IN ('STATIC','DYNAMIC')),
  merchant_id TEXT NOT NULL REFERENCES merchants(merchant_id),
  payment_intent_id TEXT REFERENCES payment_intents(payment_intent_id),
  nonce TEXT NOT NULL,
  payload_hmac TEXT NOT NULL,
  amount_minor INTEGER CHECK (amount_minor IS NULL OR amount_minor > 0),
  consumed BOOLEAN NOT NULL DEFAULT FALSE,
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (environment, nonce)
);

CREATE TABLE invoices (
  invoice_id TEXT PRIMARY KEY CHECK (invoice_id LIKE 'sbx_%'),
  environment TEXT NOT NULL REFERENCES environments_allowed(environment),
  merchant_id TEXT NOT NULL REFERENCES merchants(merchant_id),
  buyer_id TEXT,
  status TEXT NOT NULL CHECK (status IN (
    'DRAFT','SENT','VIEWED','PARTIALLY_PAID','PAID','OVERDUE','CANCELLED','REFUNDED'
  )),
  currency TEXT NOT NULL CHECK (currency = 'CAD'),
  total_minor INTEGER NOT NULL CHECK (total_minor > 0),
  paid_minor INTEGER NOT NULL DEFAULT 0 CHECK (paid_minor >= 0),
  refunded_minor INTEGER NOT NULL DEFAULT 0 CHECK (refunded_minor >= 0),
  due_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (paid_minor <= total_minor),
  CHECK (refunded_minor <= paid_minor)
);

CREATE TABLE invoice_line_items (
  line_id TEXT PRIMARY KEY CHECK (line_id LIKE 'sbx_%'),
  invoice_id TEXT NOT NULL REFERENCES invoices(invoice_id),
  description TEXT NOT NULL,
  quantity INTEGER NOT NULL CHECK (quantity > 0),
  unit_minor INTEGER NOT NULL CHECK (unit_minor >= 0),
  tax_minor INTEGER NOT NULL DEFAULT 0 CHECK (tax_minor >= 0),
  discount_minor INTEGER NOT NULL DEFAULT 0 CHECK (discount_minor >= 0)
);

CREATE TABLE invoice_events (
  invoice_event_id TEXT PRIMARY KEY CHECK (invoice_event_id LIKE 'sbx_%'),
  invoice_id TEXT NOT NULL REFERENCES invoices(invoice_id),
  from_status TEXT,
  to_status TEXT NOT NULL,
  actor_id TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------------
-- Payables / payouts / refunds / disputes / orders
-- ---------------------------------------------------------------------------

CREATE TABLE payables (
  payable_id TEXT PRIMARY KEY CHECK (payable_id LIKE 'sbx_%'),
  environment TEXT NOT NULL REFERENCES environments_allowed(environment),
  source_type TEXT NOT NULL,
  source_id TEXT NOT NULL,
  merchant_id TEXT REFERENCES merchants(merchant_id),
  beneficiary_id TEXT NOT NULL,
  currency TEXT NOT NULL CHECK (currency = 'CAD'),
  eligible_minor INTEGER NOT NULL CHECK (eligible_minor >= 0),
  reserved_minor INTEGER NOT NULL DEFAULT 0 CHECK (reserved_minor >= 0),
  paid_minor INTEGER NOT NULL DEFAULT 0 CHECK (paid_minor >= 0),
  source_settled BOOLEAN NOT NULL DEFAULT FALSE,
  status TEXT NOT NULL CHECK (status IN ('OPEN','RESERVED','PAID','CANCELLED')),
  CHECK (reserved_minor + paid_minor <= eligible_minor)
);

CREATE TABLE payouts (
  payout_id TEXT PRIMARY KEY CHECK (payout_id LIKE 'sbx_%'),
  environment TEXT NOT NULL REFERENCES environments_allowed(environment),
  payable_id TEXT NOT NULL REFERENCES payables(payable_id),
  amount_minor INTEGER NOT NULL CHECK (amount_minor > 0),
  currency TEXT NOT NULL CHECK (currency = 'CAD'),
  destination_token_ref TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN (
    'REQUESTED','VALIDATED','APPROVED','SUBMITTED','PROCESSING','SETTLED','FAILED','CANCELLED'
  )),
  requested_by TEXT NOT NULL REFERENCES users(user_id),
  approved_by TEXT REFERENCES users(user_id),
  partner_event_id TEXT REFERENCES partner_events(partner_event_id),
  reconciliation_key TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (environment, reconciliation_key),
  CHECK (approved_by IS NULL OR approved_by <> requested_by)
);

CREATE TABLE refunds (
  refund_id TEXT PRIMARY KEY CHECK (refund_id LIKE 'sbx_%'),
  environment TEXT NOT NULL REFERENCES environments_allowed(environment),
  payment_intent_id TEXT NOT NULL REFERENCES payment_intents(payment_intent_id),
  amount_minor INTEGER NOT NULL CHECK (amount_minor > 0),
  currency TEXT NOT NULL CHECK (currency = 'CAD'),
  status TEXT NOT NULL CHECK (status IN ('REQUESTED','POSTED','SETTLED','FAILED')),
  reason TEXT,
  created_by TEXT NOT NULL REFERENCES users(user_id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE disputes (
  dispute_id TEXT PRIMARY KEY CHECK (dispute_id LIKE 'sbx_%'),
  environment TEXT NOT NULL REFERENCES environments_allowed(environment),
  payment_intent_id TEXT NOT NULL REFERENCES payment_intents(payment_intent_id),
  amount_minor INTEGER NOT NULL CHECK (amount_minor > 0),
  currency TEXT NOT NULL CHECK (currency = 'CAD'),
  status TEXT NOT NULL CHECK (status IN ('OPEN','UNDER_REVIEW','WON','LOST','CLOSED')),
  reason_code TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE orders (
  order_id TEXT PRIMARY KEY CHECK (order_id LIKE 'sbx_%'),
  environment TEXT NOT NULL REFERENCES environments_allowed(environment),
  merchant_id TEXT NOT NULL REFERENCES merchants(merchant_id),
  buyer_id TEXT,
  currency TEXT NOT NULL CHECK (currency = 'CAD'),
  total_minor INTEGER NOT NULL CHECK (total_minor > 0),
  status TEXT NOT NULL CHECK (status IN ('CREATED','PAID','FULFILLED','CANCELLED','REFUNDED')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE order_allocations (
  allocation_id TEXT PRIMARY KEY CHECK (allocation_id LIKE 'sbx_%'),
  order_id TEXT NOT NULL REFERENCES orders(order_id),
  bucket TEXT NOT NULL CHECK (bucket IN (
    'seller_gross','platform_fee','tax','delivery','refund_reserve','tip','donation_restricted'
  )),
  amount_minor INTEGER NOT NULL CHECK (amount_minor >= 0),
  account_purpose TEXT NOT NULL
);

-- ---------------------------------------------------------------------------
-- Donations — schema present, product flag OFF in application
-- ---------------------------------------------------------------------------

CREATE TABLE donation_campaigns (
  campaign_id TEXT PRIMARY KEY CHECK (campaign_id LIKE 'sbx_%'),
  environment TEXT NOT NULL REFERENCES environments_allowed(environment),
  owner_id TEXT NOT NULL REFERENCES users(user_id),
  title TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN (
    'DRAFT','VERIFICATION','ACTIVE_SANDBOX','PAUSED','COMPLETED','CLOSED'
  )),
  -- LIVE_PENDING / LIVE_ACTIVE omitted
  restricted_account_id TEXT REFERENCES accounts(account_id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE donation_pledges (
  pledge_id TEXT PRIMARY KEY CHECK (pledge_id LIKE 'sbx_%'),
  campaign_id TEXT NOT NULL REFERENCES donation_campaigns(campaign_id),
  donor_id TEXT NOT NULL REFERENCES users(user_id),
  amount_minor INTEGER NOT NULL CHECK (amount_minor > 0),
  status TEXT NOT NULL CHECK (status IN ('BLOCKED_FEATURE_OFF','RECORDED','REFUNDED')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------------
-- Reconciliation
-- ---------------------------------------------------------------------------

CREATE TABLE reconciliation_runs (
  run_id TEXT PRIMARY KEY CHECK (run_id LIKE 'sbx_%'),
  environment TEXT NOT NULL REFERENCES environments_allowed(environment),
  run_date DATE NOT NULL,
  partner_position_minor INTEGER NOT NULL,
  platform_liability_minor INTEGER NOT NULL,
  difference_minor INTEGER NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('CLEAN','BREAK','FROZEN')),
  created_by TEXT NOT NULL REFERENCES users(user_id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE reconciliation_breaks (
  break_id TEXT PRIMARY KEY CHECK (break_id LIKE 'sbx_%'),
  run_id TEXT NOT NULL REFERENCES reconciliation_runs(run_id),
  description TEXT NOT NULL,
  amount_minor INTEGER NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('OPEN','ASSIGNED','CLOSED')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE feature_flags (
  flag TEXT PRIMARY KEY,
  enabled BOOLEAN NOT NULL DEFAULT FALSE CHECK (enabled = FALSE),
  note TEXT NOT NULL
);

INSERT INTO feature_flags (flag, enabled, note) VALUES
  ('LIVE_MONEY_ENABLED', FALSE, 'Sealed false. Boot must fail if true.'),
  ('DONATIONS_ENABLED', FALSE, 'Schema only until classification memo.'),
  ('CROWDFUNDING_OFFERED', FALSE, 'Phase 2 matrix NOT_OFFERED still stands.'),
  ('CARDS_EXECUTION', FALSE, 'Out of Phase 10 scope.'),
  ('FX_EXECUTION', FALSE, 'Out of Phase 10 scope.'),
  ('REMITTANCE_EXECUTION', FALSE, 'Out of Phase 10 scope.'),
  ('KDN_PRODUCTION_WRITE', FALSE, 'Out of Phase 10 scope.');

COMMIT;
