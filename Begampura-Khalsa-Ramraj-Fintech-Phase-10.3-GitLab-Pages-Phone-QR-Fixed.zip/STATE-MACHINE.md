# STATE-MACHINE — Phase 10 canonical model

P3 `CREATED/SUBMITTED` and P8/P9 `INITIATED/RISK_CHECKED/POSTED` are retired.

Every payment intent has three fields.

## intent_status

`CREATED | REQUIRES_ACTION | AUTHORIZED | CANCELLED | EXPIRED | FAILED`

| from | allowed to |
|---|---|
| CREATED | REQUIRES_ACTION, AUTHORIZED, CANCELLED, EXPIRED, FAILED |
| REQUIRES_ACTION | AUTHORIZED, EXPIRED, CANCELLED, FAILED |
| AUTHORIZED | CANCELLED, FAILED |
| CANCELLED / EXPIRED / FAILED | ∅ |

Money progress after AUTHORIZED is recorded on `settlement_status`, not by inventing extra intent names.

## settlement_status

`NOT_APPLICABLE | POSTED | PENDING_SETTLEMENT | SETTLED | RETURNED`

| from | allowed to | extra gate |
|---|---|---|
| NOT_APPLICABLE | POSTED | ledger journal sealed |
| POSTED | PENDING_SETTLEMENT, RETURNED | |
| PENDING_SETTLEMENT | SETTLED, RETURNED | **SETTLED only if verified partner_event exists** |
| SETTLED | ∅ | frontend success cannot enter here |
| RETURNED | ∅ | |

## exception_status

`NONE | REVERSED | REFUNDED | DISPUTED`

| from | allowed to |
|---|---|
| NONE | REVERSED, REFUNDED, DISPUTED |
| REVERSED | ∅ |
| REFUNDED | DISPUTED |
| DISPUTED | REFUNDED |

Reversal of ledger value is a **new journal**, not an edit.

## Invoice

`DRAFT → SENT → VIEWED|PARTIALLY_PAID|PAID|OVERDUE|CANCELLED`  
`PAID → REFUNDED` only. **`PAID → OVERDUE` is illegal.**

## Payout

`REQUESTED → VALIDATED → APPROVED → SUBMITTED → PROCESSING → SETTLED`  
Engine writes `VALIDATED` after source-settled + limit checks.  
`SETTLED` payout still needs a partner event in a later call; Phase 10 tests stop at APPROVED for maker/checker.

## Merchant / campaign

Merchant statuses exclude `LIVE_PENDING` and `LIVE_ACTIVE`.  
SQL CHECK rejects those strings. Transition is impossible.
