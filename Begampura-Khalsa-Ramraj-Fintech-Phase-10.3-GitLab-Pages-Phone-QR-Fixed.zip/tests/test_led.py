import pytest

from bfn_sandbox.errors import LedgerError


def test_t_led_01_one_hundred_thousand_balanced_journals(engine):
    actor = {"user_id": "sbx_user_system", "role": "system"}
    engine.bulk_balanced_journals(actor, 100_000)
    n = engine.conn.execute("SELECT COUNT(*) c FROM ledger_journals").fetchone()["c"]
    assert n == 100_000
    unbalanced = engine.conn.execute(
        """SELECT COUNT(*) c FROM (
             SELECT journal_id FROM ledger_entries
             GROUP BY journal_id
             HAVING SUM(debit_minor) != SUM(credit_minor)
           )"""
    ).fetchone()["c"]
    assert unbalanced == 0


def test_t_led_02_update_delete_posted_entries_fail(engine):
    actor = {"user_id": "sbx_user_system", "role": "system"}
    jid = engine.post_journal(
        actor,
        "sale",
        "sbx_src_immut",
        [("sbx_acct_customer_pool", 50, 0), ("sbx_acct_hold", 0, 50)],
    )
    entry = engine.conn.execute(
        "SELECT entry_id FROM ledger_entries WHERE journal_id=?", (jid,)
    ).fetchone()["entry_id"]
    with pytest.raises(LedgerError):
        engine.mutate_entry(entry, debit_minor=1)
    with pytest.raises(LedgerError):
        engine.delete_entry(entry)


def test_t_led_03_reversal_creates_new_journal(engine):
    actor = {"user_id": "sbx_user_system", "role": "system"}
    jid = engine.post_journal(
        actor,
        "sale",
        "sbx_src_rev",
        [("sbx_acct_customer_pool", 80, 0), ("sbx_acct_hold", 0, 80)],
    )
    rev = engine.reverse_journal(actor, jid)
    assert rev != jid
    original = engine.conn.execute(
        "SELECT sealed FROM ledger_journals WHERE journal_id=?", (jid,)
    ).fetchone()
    assert original["sealed"] == 1
    assert engine.journal_balanced(jid)
    assert engine.journal_balanced(rev)
    row = engine.conn.execute(
        "SELECT reverses_journal_id FROM ledger_journals WHERE journal_id=?", (rev,)
    ).fetchone()
    assert row["reverses_journal_id"] == jid


def test_unbalanced_journal_rejected(engine):
    actor = {"user_id": "sbx_user_system", "role": "system"}
    with pytest.raises(LedgerError):
        engine.post_journal(
            actor,
            "bad",
            "sbx_src_bad",
            [("sbx_acct_customer_pool", 10, 0), ("sbx_acct_hold", 0, 9)],
        )


def test_donation_cannot_hit_operating(engine, actors):
    with pytest.raises(LedgerError, match="operating"):
        engine.post_donation_to_operating(actors["owner"], 100)
