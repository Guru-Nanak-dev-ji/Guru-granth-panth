import os

import pytest

from bfn_sandbox.config import assert_boot_safe, default_config
from bfn_sandbox.errors import BootError, LedgerError, Unprocessable


def test_t_iso_01_environment_only_local_or_sandbox():
    cfg = default_config()
    cfg["environment"] = "production"
    with pytest.raises(BootError):
        assert_boot_safe(cfg)


def test_t_iso_02_ids_require_sbx_prefix(engine):
    with pytest.raises(Exception):
        engine.conn.execute(
            """INSERT INTO users(user_id,environment,handle,role,status)
               VALUES ('user_nope','sandbox','x','owner','ACTIVE')"""
        )


def test_t_sec_01_production_credential_boot_failure():
    cfg = default_config()
    cfg["secrets"] = {"processor_key": "sk_live_this_must_fail"}
    with pytest.raises(BootError, match="production-class"):
        assert_boot_safe(cfg)


def test_t_sec_01b_live_env_key(monkeypatch):
    monkeypatch.setenv("STRIPE_LIVE_SECRET_KEY", "whatever")
    with pytest.raises(BootError):
        assert_boot_safe(default_config())


def test_t_live_flag_true_boot_failure():
    cfg = default_config()
    cfg["live_money_enabled"] = True
    with pytest.raises(BootError, match="LIVE_MONEY"):
        assert_boot_safe(cfg)


def test_t_live_env_true_boot_failure(monkeypatch):
    monkeypatch.setenv("LIVE_MONEY_ENABLED", "true")
    with pytest.raises(BootError):
        assert_boot_safe(default_config())


def test_bank_claim_boot_failure():
    cfg = default_config()
    cfg["public_claims"] = {"uses_word_bank": True, "licensed_bank": False}
    with pytest.raises(BootError):
        assert_boot_safe(cfg)


def test_cad_only(engine, actors):
    with pytest.raises(Unprocessable):
        engine.create_intent(
            actors["owner"],
            {
                "merchant_id": actors["merchant"]["merchant_id"],
                "amount_minor": 100,
                "currency": "USD",
            },
            "usd-1",
        )


def test_points_book_cannot_mix(engine):
    actor = {"user_id": "sbx_user_system", "role": "system"}
    engine.conn.execute(
        """INSERT INTO accounts(account_id,environment,currency,book,owner_type,owner_id,purpose)
           VALUES ('sbx_acct_points','sandbox','CAD','SANDBOX_POINTS','platform','sbx_user_system','operating')"""
    )
    with pytest.raises(LedgerError):
        engine.post_journal(
            actor,
            "mix",
            "sbx_mix",
            [("sbx_acct_customer_pool", 5, 0), ("sbx_acct_points", 0, 5)],
        )
