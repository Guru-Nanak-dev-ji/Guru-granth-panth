import pytest

from bfn_sandbox.errors import Forbidden, Unprocessable
from bfn_sandbox.state_machine import INVOICE_TRANSITIONS, move


def test_t_pay_01_frontend_success_cannot_settle(engine, actors):
    intent = engine.create_intent(
        actors["owner"],
        {"merchant_id": actors["merchant"]["merchant_id"], "amount_minor": 1500, "currency": "CAD"},
        "pay-1",
    )
    engine.authorize_and_post(actors["owner"], intent["payment_intent_id"])
    shown = engine.frontend_success(intent["payment_intent_id"])
    assert shown["settlement_status"] != "SETTLED"
    assert engine.get_intent(intent["payment_intent_id"])["settlement_status"] == "POSTED"


def test_t_pay_02_qr_reuse_rejected(engine, actors):
    qr = engine.issue_qr(actors["owner"], actors["merchant"]["merchant_id"], "DYNAMIC", 1200, "qr-reuse")
    engine.conn.execute("UPDATE qr_tokens SET consumed=1 WHERE qr_token_id=?", (qr["qr_token_id"],))
    engine.conn.commit()
    with pytest.raises(Unprocessable, match="consumed"):
        engine.resolve_qr(actors["cashier"], qr["qr_token_id"])


def test_t_pay_03_dynamic_qr_expiry(engine, actors):
    qr = engine.issue_qr(actors["owner"], actors["merchant"]["merchant_id"], "DYNAMIC", 800, "qr-expiry")
    engine.conn.execute("UPDATE qr_tokens SET expires_at=1 WHERE qr_token_id=?", (qr["qr_token_id"],))
    engine.conn.commit()
    with pytest.raises(Unprocessable, match="expired"):
        engine.resolve_qr(actors["cashier"], qr["qr_token_id"])


def test_t_pay_04_tampered_qr_amount_server_wins(engine, actors):
    qr = engine.issue_qr(actors["owner"], actors["merchant"]["merchant_id"], "DYNAMIC", 2200, "qr-tamper")
    resolved = engine.resolve_qr(actors["cashier"], qr["qr_token_id"], presented_amount=1)
    assert resolved["amount_minor"] == 2200


def test_invoice_paid_cannot_become_overdue(engine, actors):
    inv = engine.create_invoice(actors["owner"], actors["merchant"]["merchant_id"], 5000, "invoice-paid")
    sent = engine.transition_invoice(actors["owner"], inv["invoice_id"], "SENT")
    assert sent["status"] == "SENT"
    with pytest.raises(Unprocessable, match="invoice_status"):
        move("PAID", "OVERDUE", INVOICE_TRANSITIONS, "invoice_status")


def _settled_payable(engine, actors, amount=5000):
    intent = engine.create_intent(
        actors["owner"],
        {"merchant_id": actors["merchant"]["merchant_id"], "amount_minor": amount, "currency": "CAD"},
        f"settle-{amount}",
    )
    engine.authorize_and_post(actors["owner"], intent["payment_intent_id"])
    engine.mark_pending_settlement(actors["owner"], intent["payment_intent_id"])
    engine.partner_settle(intent["payment_intent_id"])
    row = engine.conn.execute(
        "SELECT payable_id FROM payables WHERE source_id=?",
        (intent["payment_intent_id"],),
    ).fetchone()
    return row["payable_id"]


def test_t_po_01_payout_exceeds_eligible(engine, actors):
    payable_id = _settled_payable(engine, actors, 5000)
    with pytest.raises(Unprocessable, match="exceeds"):
        engine.request_payout(actors["owner"], payable_id, 5001, "sbx_dest_1", "po-big")


def test_t_po_02_payout_from_unsettled_rejected(engine, actors):
    engine.conn.execute(
        """INSERT INTO payables(payable_id,environment,source_type,source_id,merchant_id,beneficiary_id,
           currency,eligible_minor,source_settled,status)
           VALUES (?,?,?,?,?,?,?,?,0,'OPEN')""",
        (
            "sbx_payble_unset",
            engine.env,
            "payment_intent",
            "sbx_pi_fake",
            actors["merchant"]["merchant_id"],
            actors["merchant"]["merchant_id"],
            "CAD",
            1000,
        ),
    )
    engine.conn.commit()
    with pytest.raises(Unprocessable, match="unsettled"):
        engine.request_payout(actors["owner"], "sbx_payble_unset", 100, "sbx_dest_1", "po-unset")


def test_t_po_04_maker_cannot_approve(engine, actors):
    payable_id = _settled_payable(engine, actors, 3000)
    po = engine.request_payout(actors["owner"], payable_id, 1000, "sbx_dest_1", "po-maker")
    with pytest.raises(Forbidden, match="maker"):
        engine.approve_payout(actors["owner"], po["payout_id"])


def test_finance_can_approve_owner_payout(engine, actors):
    payable_id = _settled_payable(engine, actors, 4000)
    po = engine.request_payout(actors["owner"], payable_id, 1000, "sbx_dest_2", "po-ok")
    approved = engine.approve_payout(actors["finance"], po["payout_id"])
    assert approved["status"] == "APPROVED"
    assert approved["approved_by"] != approved["requested_by"]


def test_donations_feature_off(engine, actors):
    with pytest.raises(Unprocessable, match="not offered"):
        engine.create_campaign(actors["owner"], "Kitchen")
    with pytest.raises(Unprocessable, match="donation"):
        engine.create_intent(
            actors["owner"],
            {
                "merchant_id": actors["merchant"]["merchant_id"],
                "amount_minor": 100,
                "currency": "CAD",
                "purpose": "donation",
            },
            "don-1",
        )
