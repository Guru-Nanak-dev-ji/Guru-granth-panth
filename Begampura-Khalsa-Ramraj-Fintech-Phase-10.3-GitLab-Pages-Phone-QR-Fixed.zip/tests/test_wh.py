import time

import pytest

from bfn_sandbox.crypto_webhooks import make_header
from bfn_sandbox.errors import Unprocessable


def _signed(engine, payment_intent_id, event_type="settled", ext=None, ts=None):
    bundle = engine.mock_partner_emit(event_type, payment_intent_id, external_event_id=ext)
    header = make_header(engine.keys.active[1], bundle["raw"], timestamp=ts)
    return bundle, header


def test_t_wh_01_valid_signature_one_transition(engine, actors):
    intent = engine.create_intent(
        actors["owner"],
        {
            "merchant_id": actors["merchant"]["merchant_id"],
            "amount_minor": 900,
            "currency": "CAD",
        },
        "wh-1",
    )
    engine.authorize_and_post(actors["owner"], intent["payment_intent_id"])
    engine.mark_pending_settlement(actors["owner"], intent["payment_intent_id"])
    engine.partner_settle(intent["payment_intent_id"])
    got = engine.get_intent(intent["payment_intent_id"])
    assert got["settlement_status"] == "SETTLED"
    journals = engine.conn.execute(
        "SELECT COUNT(*) c FROM ledger_journals WHERE source_id LIKE ?",
        (intent["payment_intent_id"] + "%",),
    ).fetchone()["c"]
    assert journals == 2  # post + settle


def test_t_wh_02_replay_no_second_journal(engine, actors):
    intent = engine.create_intent(
        actors["owner"],
        {"merchant_id": actors["merchant"]["merchant_id"], "amount_minor": 700, "currency": "CAD"},
        "wh-2",
    )
    engine.authorize_and_post(actors["owner"], intent["payment_intent_id"])
    engine.mark_pending_settlement(actors["owner"], intent["payment_intent_id"])
    bundle, header = _signed(engine, intent["payment_intent_id"], ext="sbx_pevt_replay")
    engine.ingest_webhook(actors["partner"], bundle["raw"], header)
    before = engine.conn.execute("SELECT COUNT(*) c FROM ledger_journals").fetchone()["c"]
    replay = engine.ingest_webhook(actors["partner"], bundle["raw"], header)
    after = engine.conn.execute("SELECT COUNT(*) c FROM ledger_journals").fetchone()["c"]
    assert replay["disposition"] == "REPLAY"
    assert before == after


def test_t_wh_03_bad_signature_cannot_settle(engine, actors):
    intent = engine.create_intent(
        actors["owner"],
        {"merchant_id": actors["merchant"]["merchant_id"], "amount_minor": 600, "currency": "CAD"},
        "wh-3",
    )
    engine.authorize_and_post(actors["owner"], intent["payment_intent_id"])
    engine.mark_pending_settlement(actors["owner"], intent["payment_intent_id"])
    bundle, _ = _signed(engine, intent["payment_intent_id"])
    with pytest.raises(Unprocessable, match="signature"):
        engine.ingest_webhook(actors["partner"], bundle["raw"], "t=1,v1=deadbeef")
    assert engine.get_intent(intent["payment_intent_id"])["settlement_status"] != "SETTLED"


def test_t_wh_04_timestamp_skew_rejected(engine, actors):
    intent = engine.create_intent(
        actors["owner"],
        {"merchant_id": actors["merchant"]["merchant_id"], "amount_minor": 400, "currency": "CAD"},
        "wh-4",
    )
    bundle, header = _signed(engine, intent["payment_intent_id"], ts=int(time.time()) - 10_000)
    with pytest.raises(Unprocessable, match="skew"):
        engine.ingest_webhook(actors["partner"], bundle["raw"], header, now=int(time.time()))


def test_t_wh_05_out_of_order_cannot_move_settled_backward(engine, actors):
    intent = engine.create_intent(
        actors["owner"],
        {"merchant_id": actors["merchant"]["merchant_id"], "amount_minor": 300, "currency": "CAD"},
        "wh-5",
    )
    engine.authorize_and_post(actors["owner"], intent["payment_intent_id"])
    engine.mark_pending_settlement(actors["owner"], intent["payment_intent_id"])
    engine.partner_settle(intent["payment_intent_id"])
    bundle, header = _signed(engine, intent["payment_intent_id"], event_type="authorized", ext="sbx_late")
    result = engine.ingest_webhook(actors["partner"], bundle["raw"], header)
    assert result["disposition"] == "IGNORED_OUT_OF_ORDER"
    assert engine.get_intent(intent["payment_intent_id"])["settlement_status"] == "SETTLED"


def test_rotated_key_still_accepted(engine, actors):
    intent = engine.create_intent(
        actors["owner"],
        {"merchant_id": actors["merchant"]["merchant_id"], "amount_minor": 200, "currency": "CAD"},
        "wh-rot",
    )
    engine.authorize_and_post(actors["owner"], intent["payment_intent_id"])
    engine.mark_pending_settlement(actors["owner"], intent["payment_intent_id"])
    bundle = engine.mock_partner_emit("settled", intent["payment_intent_id"], "sbx_rot")
    header = make_header(engine.keys.rotated[1], bundle["raw"])
    result = engine.ingest_webhook(actors["partner"], bundle["raw"], header)
    assert result["disposition"] == "ACCEPTED"
