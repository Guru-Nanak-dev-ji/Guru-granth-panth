"""Dependency-free smoke test for the new Phase 10 browser demo path."""
from pathlib import Path
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from bfn_sandbox.demo_server import Demo


def main() -> None:
    with tempfile.TemporaryDirectory() as directory:
        demo = Demo(Path(directory) / "demo.sqlite3")
        state = demo.create(2500)
        assert state["live_money_enabled"] is False
        assert state["intent"]["amount_minor"] == 2500
        assert demo.scan()["resolved"]["amount_minor"] == 2500
        assert demo.settle()["intent"]["settlement_status"] == "SETTLED"
        assert demo.payout()["payout"]["status"] == "APPROVED"
        assert demo.reconcile()["reconciliation"]["status"] == "CLEAN"
    print("DEMO FLOW PASS: QR -> SETTLED -> APPROVED -> CLEAN; LIVE_MONEY_ENABLED=false")


if __name__ == "__main__":
    main()
