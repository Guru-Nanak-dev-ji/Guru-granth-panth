import pytest

from bfn_sandbox.errors import KillSwitchActive


def test_t_kill_01_blocks_mutations_allows_reads(engine, actors):
    intent = engine.create_intent(
        actors["owner"],
        {"merchant_id": actors["merchant"]["merchant_id"], "amount_minor": 1000, "currency": "CAD"},
        "kill-setup",
    )
    engine.set_kill_switch(actors["admin"], "pause_payment_initiation", True, "drill")
    with pytest.raises(KillSwitchActive):
        engine.create_intent(
            actors["owner"],
            {"merchant_id": actors["merchant"]["merchant_id"], "amount_minor": 1000, "currency": "CAD"},
            "kill-new",
        )
    got = engine.get_intent(intent["payment_intent_id"])
    assert got["payment_intent_id"] == intent["payment_intent_id"]
    assert got["amount_minor"] == 1000


def test_payout_kill_switch(engine, actors):
    engine.set_kill_switch(actors["admin"], "pause_payouts", True, "drill")
    engine.conn.execute(
        """INSERT INTO payables(payable_id,environment,source_type,source_id,merchant_id,beneficiary_id,
           currency,eligible_minor,source_settled,status)
           VALUES (?,?,?,?,?,?,?,?,1,'OPEN')""",
        (
            "sbx_payble_k",
            engine.env,
            "payment_intent",
            "sbx_pi_k",
            actors["merchant"]["merchant_id"],
            actors["merchant"]["merchant_id"],
            "CAD",
            1000,
        ),
    )
    engine.conn.commit()
    with pytest.raises(KillSwitchActive):
        engine.request_payout(actors["owner"], "sbx_payble_k", 100, "d", "k2")


def test_recon_break_freezes_outbound(engine, actors):
    result = engine.run_reconciliation(actors["compliance"], partner_position_minor=10, platform_liability_minor=0)
    assert result["status"] == "BREAK"
    with pytest.raises(KillSwitchActive):
        engine.create_intent(
            actors["owner"],
            {"merchant_id": actors["merchant"]["merchant_id"], "amount_minor": 100, "currency": "CAD"},
            "after-break",
        )
