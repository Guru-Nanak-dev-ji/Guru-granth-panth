import json
import time

import pytest

from bfn_sandbox.crypto_webhooks import encode_event, make_header
from bfn_sandbox.errors import Conflict, Forbidden, Unprocessable


def _ready_intent(engine, actors, key="hardening-ready", amount=1250):
    intent = engine.create_intent(
        actors["owner"],
        {
            "merchant_id": actors["merchant"]["merchant_id"],
            "amount_minor": amount,
            "currency": "CAD",
        },
        key,
    )
    engine.authorize_and_post(actors["owner"], intent["payment_intent_id"])
    engine.mark_pending_settlement(actors["owner"], intent["payment_intent_id"])
    return intent


def test_t_wh_06_invalid_signature_cannot_poison_external_event_id(engine, actors):
    intent = _ready_intent(engine, actors, "wh-poison")
    ext = "sbx_pevt_poison_guard"
    bundle = engine.mock_partner_emit("settled", intent["payment_intent_id"], ext)
    now = int(time.time())
    bad_header = f"t={now},v1={'0' * 64}"

    with pytest.raises(Unprocessable, match="signature"):
        engine.ingest_webhook(actors["partner"], bundle["raw"], bad_header, now=now)

    # Unverified input must not reserve the replay key.
    count = engine.conn.execute(
        "SELECT COUNT(*) c FROM webhook_receipts WHERE external_event_id=?", (ext,)
    ).fetchone()["c"]
    assert count == 0

    good_header = make_header(engine.keys.active[1], bundle["raw"], timestamp=now)
    result = engine.ingest_webhook(actors["partner"], bundle["raw"], good_header, now=now)
    assert result["disposition"] == "ACCEPTED"
    assert engine.get_intent(intent["payment_intent_id"])["settlement_status"] == "SETTLED"


def test_t_wh_07_unknown_event_type_is_clean_422(engine, actors):
    intent = _ready_intent(engine, actors, "wh-unknown-event")
    event = {
        "partner_source": "mock_partner",
        "event_type": "teleport_money",
        "payment_intent_id": intent["payment_intent_id"],
        "external_event_id": "sbx_pevt_unknown_type",
    }
    raw = encode_event(event)
    header = make_header(engine.keys.active[1], raw)
    with pytest.raises(Unprocessable, match="event_type") as exc:
        engine.ingest_webhook(actors["partner"], raw, header)
    assert exc.value.status_code == 422


def test_t_wh_08_missing_external_event_id_is_clean_422(engine, actors):
    intent = _ready_intent(engine, actors, "wh-missing-ext")
    event = {
        "partner_source": "mock_partner",
        "event_type": "settled",
        "payment_intent_id": intent["payment_intent_id"],
    }
    raw = encode_event(event)
    header = make_header(engine.keys.active[1], raw)
    with pytest.raises(Unprocessable, match="external_event_id") as exc:
        engine.ingest_webhook(actors["partner"], raw, header)
    assert exc.value.status_code == 422


def test_t_wh_09_missing_payment_intent_id_is_clean_422(engine, actors):
    event = {
        "partner_source": "mock_partner",
        "event_type": "settled",
        "external_event_id": "sbx_pevt_missing_pi",
    }
    raw = encode_event(event)
    header = make_header(engine.keys.active[1], raw)
    with pytest.raises(Unprocessable, match="payment_intent_id") as exc:
        engine.ingest_webhook(actors["partner"], raw, header)
    assert exc.value.status_code == 422


def test_t_wh_10_malformed_timestamp_is_clean_422(engine, actors):
    raw = json.dumps({"x": 1}).encode()
    with pytest.raises(Unprocessable, match="malformed signature") as exc:
        engine.ingest_webhook(actors["partner"], raw, "t=not-a-number,v1=deadbeef")
    assert exc.value.status_code == 422


def test_t_wh_11_same_external_id_different_verified_payload_conflicts(engine, actors):
    intent = _ready_intent(engine, actors, "wh-collision")
    ext = "sbx_pevt_collision"
    first = engine.mock_partner_emit("settled", intent["payment_intent_id"], ext)
    first_header = make_header(engine.keys.active[1], first["raw"])
    engine.ingest_webhook(actors["partner"], first["raw"], first_header)

    second_event = {
        "partner_source": "mock_partner",
        "event_type": "authorized",
        "payment_intent_id": intent["payment_intent_id"],
        "external_event_id": ext,
    }
    second_raw = encode_event(second_event)
    second_header = make_header(engine.keys.active[1], second_raw)
    with pytest.raises(Conflict, match="different payload"):
        engine.ingest_webhook(actors["partner"], second_raw, second_header)


def test_t_auth_04_support_cannot_create_merchant(engine, actors):
    with pytest.raises(Forbidden, match="owner"):
        engine.create_merchant(actors["support"], "Unauthorized Shop", "support-create")


def test_t_auth_05_cross_merchant_intent_blocked(engine, actors):
    other_owner = engine.create_user("other-owner", "owner")
    other_merchant = engine.create_merchant(other_owner, "Other Shop", "other-shop")
    with pytest.raises(Forbidden, match="membership"):
        engine.create_intent(
            actors["owner"],
            {
                "merchant_id": other_merchant["merchant_id"],
                "amount_minor": 500,
                "currency": "CAD",
            },
            "cross-merchant-intent",
        )


def test_t_auth_06_nonmember_cashier_cannot_issue_qr(engine, actors):
    outsider = engine.create_user("outsider-cashier", "cashier")
    with pytest.raises(Forbidden, match="membership"):
        engine.issue_qr(outsider, actors["merchant"]["merchant_id"], "STATIC", idempotency_key="outsider-qr")


def test_t_auth_07_cross_merchant_invoice_blocked(engine, actors):
    other_owner = engine.create_user("invoice-other-owner", "owner")
    other_merchant = engine.create_merchant(other_owner, "Invoice Other", "invoice-other")
    with pytest.raises(Forbidden, match="membership"):
        engine.create_invoice(actors["owner"], other_merchant["merchant_id"], 1000, "cross-invoice")


def test_t_auth_08_cross_merchant_payout_blocked(engine, actors):
    other_owner = engine.create_user("payout-other-owner", "owner")
    other_merchant = engine.create_merchant(other_owner, "Payout Other", "payout-other")
    engine.conn.execute(
        """INSERT INTO payables(payable_id,environment,source_type,source_id,merchant_id,beneficiary_id,
           currency,eligible_minor,source_settled,status)
           VALUES (?,?,?,?,?,?,?,?,1,'OPEN')""",
        (
            "sbx_payble_other_merchant",
            engine.env,
            "payment_intent",
            "sbx_pi_other",
            other_merchant["merchant_id"],
            other_merchant["merchant_id"],
            "CAD",
            1000,
        ),
    )
    engine.conn.commit()
    with pytest.raises(Forbidden, match="membership"):
        engine.request_payout(
            actors["owner"], "sbx_payble_other_merchant", 100, "sbx_dest", "cross-payout"
        )


def test_t_auth_09_revoked_member_cannot_replay_idempotent_payout(engine, actors):
    intent = _ready_intent(engine, actors, "payout-revoke", 3000)
    engine.partner_settle(intent["payment_intent_id"])
    payable = engine.conn.execute(
        "SELECT payable_id FROM payables WHERE source_id=?", (intent["payment_intent_id"],)
    ).fetchone()["payable_id"]
    first = engine.request_payout(actors["finance"], payable, 500, "sbx_dest", "revoke-replay")
    assert first["status"] == "VALIDATED"

    engine.set_merchant_member_status(
        actors["owner"], actors["merchant"]["merchant_id"], actors["finance"]["user_id"], "REVOKED"
    )
    with pytest.raises(Forbidden, match="membership"):
        engine.request_payout(actors["finance"], payable, 500, "sbx_dest", "revoke-replay")


def test_t_auth_10_forged_actor_role_rejected(engine, actors):
    forged = dict(actors["support"])
    forged["role"] = "owner"
    with pytest.raises(Forbidden, match="invalid actor"):
        engine.create_merchant(forged, "Forged Shop", "forged-shop")


def test_t_idp_04_merchant_creation_requires_key_and_replays(engine):
    owner = engine.create_user("idem-owner", "owner")
    with pytest.raises(Unprocessable, match="Idempotency-Key"):
        engine.create_merchant(owner, "Idem Shop")
    first = engine.create_merchant(owner, "Idem Shop", "merchant-idem")
    second = engine.create_merchant(owner, "Idem Shop", "merchant-idem")
    assert first["merchant_id"] == second["merchant_id"]


def test_t_idp_05_qr_creation_requires_key_and_replays(engine, actors):
    with pytest.raises(Unprocessable, match="Idempotency-Key"):
        engine.issue_qr(actors["owner"], actors["merchant"]["merchant_id"], "STATIC")
    first = engine.issue_qr(
        actors["owner"], actors["merchant"]["merchant_id"], "STATIC", idempotency_key="static-idem"
    )
    second = engine.issue_qr(
        actors["owner"], actors["merchant"]["merchant_id"], "STATIC", idempotency_key="static-idem"
    )
    assert first["qr_token_id"] == second["qr_token_id"]


def test_t_idp_06_invoice_creation_requires_key_and_replays(engine, actors):
    with pytest.raises(Unprocessable, match="Idempotency-Key"):
        engine.create_invoice(actors["owner"], actors["merchant"]["merchant_id"], 750)
    first = engine.create_invoice(
        actors["owner"], actors["merchant"]["merchant_id"], 750, "invoice-idem"
    )
    second = engine.create_invoice(
        actors["owner"], actors["merchant"]["merchant_id"], 750, "invoice-idem"
    )
    assert first["invoice_id"] == second["invoice_id"]


def test_t_auth_11_platform_compliance_can_be_independent_payout_checker(engine, actors):
    intent = _ready_intent(engine, actors, "compliance-checker", 2600)
    engine.partner_settle(intent["payment_intent_id"])
    payable = engine.conn.execute(
        "SELECT payable_id FROM payables WHERE source_id=?", (intent["payment_intent_id"],)
    ).fetchone()["payable_id"]
    payout = engine.request_payout(actors["owner"], payable, 400, "sbx_dest_comp", "comp-po")
    approved = engine.approve_payout(actors["compliance"], payout["payout_id"])
    assert approved["status"] == "APPROVED"
    assert approved["approved_by"] == actors["compliance"]["user_id"]


def test_t_auth_12_forged_admin_cannot_flip_kill_switch(engine, actors):
    forged = dict(actors["support"])
    forged["role"] = "platform_admin"
    with pytest.raises(Forbidden, match="invalid actor"):
        engine.set_kill_switch(forged, "pause_payouts", True, "forged")


def test_t_auth_13_forged_compliance_cannot_run_reconciliation(engine, actors):
    forged = dict(actors["support"])
    forged["role"] = "platform_compliance"
    with pytest.raises(Forbidden, match="invalid actor"):
        engine.run_reconciliation(forged, 10, 0)


def test_t_auth_14_membership_role_cannot_escalate_stored_user_role(engine, actors):
    outsider = engine.create_user("role-drift", "cashier")
    with pytest.raises(Unprocessable, match="match stored user role"):
        engine.add_merchant_member(
            actors["owner"], actors["merchant"]["merchant_id"], outsider, member_role="owner"
        )
