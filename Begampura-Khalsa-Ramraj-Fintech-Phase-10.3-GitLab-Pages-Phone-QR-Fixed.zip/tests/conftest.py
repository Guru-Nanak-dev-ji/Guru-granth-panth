import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from bfn_sandbox.engine import Engine


@pytest.fixture
def engine():
    return Engine()


@pytest.fixture
def actors(engine: Engine):
    owner = engine.create_user("owner1", "owner")
    finance = engine.create_user("finance1", "finance")
    cashier = engine.create_user("cashier1", "cashier")
    support = engine.create_user("support1", "support")
    analyst = engine.create_user("analyst1", "analyst")
    compliance = engine._seed_user("comp1", "platform_compliance")
    admin = engine._seed_user("admin1", "platform_admin")
    partner = engine._seed_user("partner1", "partner_tech")
    ai = engine.create_user("ai1", "ai_assistant")
    customer = engine.create_user("cust1", "customer")
    merchant = engine.create_merchant(owner, "Demo Shop", "fixture-merchant")
    engine.add_merchant_member(owner, merchant["merchant_id"], finance)
    engine.add_merchant_member(owner, merchant["merchant_id"], cashier)
    engine.add_merchant_member(owner, merchant["merchant_id"], support)
    engine.add_merchant_member(owner, merchant["merchant_id"], analyst)
    return {
        "owner": owner,
        "finance": finance,
        "cashier": cashier,
        "support": support,
        "analyst": analyst,
        "compliance": compliance,
        "admin": admin,
        "partner": partner,
        "ai": ai,
        "customer": customer,
        "merchant": merchant,
    }
