import pytest

from bfn_sandbox.errors import Forbidden, Unprocessable
from bfn_sandbox.rbac import can


def test_t_auth_01_cashier_payout_403(engine, actors):
    engine.conn.execute(
        """INSERT INTO payables(payable_id,environment,source_type,source_id,merchant_id,beneficiary_id,
           currency,eligible_minor,source_settled,status)
           VALUES (?,?,?,?,?,?,?,?,1,'OPEN')""",
        (
            "sbx_payble_cash",
            engine.env,
            "payment_intent",
            "sbx_pi_x",
            actors["merchant"]["merchant_id"],
            actors["merchant"]["merchant_id"],
            "CAD",
            1000,
        ),
    )
    engine.conn.commit()
    with pytest.raises(Forbidden) as exc:
        engine.request_payout(actors["cashier"], "sbx_payble_cash", 100, "sbx_dest", "cash-po")
    assert exc.value.status_code == 403


def test_t_auth_03_owner_cannot_flip_live(engine, actors):
    with pytest.raises(Unprocessable, match="LIVE_ACTIVE"):
        engine.try_set_merchant_live(actors["merchant"]["merchant_id"])
    status = engine.conn.execute(
        "SELECT status FROM merchants WHERE merchant_id=?",
        (actors["merchant"]["merchant_id"],),
    ).fetchone()["status"]
    assert status == "SANDBOX_ACTIVE"


def test_ai_has_no_money_permissions():
    for perm in (
        "intent.create",
        "payout.initiate",
        "payout.approve",
        "refund.initiate",
        "kill.switch",
        "live.money.enable",
    ):
        assert can("ai_assistant", perm) is False


def test_support_cannot_payout(engine, actors):
    with pytest.raises(Forbidden):
        engine.request_payout(actors["support"], "sbx_payble_x", 100, "d", "k")
