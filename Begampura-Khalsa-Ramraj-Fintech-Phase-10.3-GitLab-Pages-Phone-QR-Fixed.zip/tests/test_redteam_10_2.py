import pytest

from bfn_sandbox.config import assert_boot_safe, default_config
from bfn_sandbox.engine import Engine
from bfn_sandbox.errors import BootError, Forbidden, KillSwitchActive, Unprocessable


def _owner_merchant(e: Engine, suffix='x'):
    owner = e.create_user(f'owner-{suffix}', 'owner')
    merchant = e.create_merchant(owner, f'Shop {suffix}', f'm-{suffix}')
    return owner, merchant


def _settled_payable(e: Engine, owner, merchant, key='rt-settle', amount=1000):
    pi = e.create_intent(owner, {'merchant_id': merchant['merchant_id'], 'amount_minor': amount, 'currency': 'CAD'}, key)
    e.authorize_and_post(owner, pi['payment_intent_id'])
    e.mark_pending_settlement(owner, pi['payment_intent_id'])
    e.partner_settle(pi['payment_intent_id'])
    return e.conn.execute('SELECT payable_id FROM payables WHERE source_id=?', (pi['payment_intent_id'],)).fetchone()['payable_id']


@pytest.mark.parametrize('flag', ['cards_execution','fx_execution','remittance_execution','kdn_production_write','donations_enabled','crowdfunding_offered'])
def test_sealed_flags_fail_boot(flag):
    cfg = default_config(); cfg[flag] = True
    with pytest.raises(BootError): assert_boot_safe(cfg)


def test_live_money_truthy_string_fails_boot():
    cfg = default_config(); cfg['live_money_enabled'] = 'true'
    with pytest.raises(BootError): assert_boot_safe(cfg)


@pytest.mark.parametrize('bad',[True, 10.5, '1000'])
def test_amount_type_rejected(bad):
    e = Engine(); owner, merchant = _owner_merchant(e, str(bad))
    with pytest.raises(Unprocessable):
        e.create_intent(owner, {'merchant_id': merchant['merchant_id'], 'amount_minor': bad, 'currency':'CAD'}, f'a-{bad}')


def test_missing_amount_controlled_422():
    e=Engine(); owner, merchant = _owner_merchant(e,'missing')
    with pytest.raises(Unprocessable):
        e.create_intent(owner, {'merchant_id': merchant['merchant_id'], 'currency':'CAD'}, 'missing')


def test_invalid_payer_controlled_422():
    e=Engine(); owner, merchant = _owner_merchant(e,'payer')
    with pytest.raises(Unprocessable):
        e.create_intent(owner, {'merchant_id': merchant['merchant_id'], 'payer_id':'sbx_user_missing', 'amount_minor':100, 'currency':'CAD'}, 'payer')


def test_intent_requires_merchant():
    e=Engine(); finance = e.create_user('fin','finance')
    with pytest.raises(Unprocessable):
        e.create_intent(finance, {'amount_minor':500,'currency':'CAD'}, 'orphan')


def test_non_string_idempotency_key_rejected():
    e=Engine(); owner, merchant = _owner_merchant(e,'idem')
    with pytest.raises(Unprocessable):
        e.create_intent(owner, {'merchant_id': merchant['merchant_id'], 'amount_minor':100,'currency':'CAD'}, 12345)


def test_support_cannot_authorize_and_analyst_cannot_mark_pending():
    e=Engine(); owner, merchant = _owner_merchant(e,'rbac')
    support=e.create_user('support','support'); analyst=e.create_user('analyst','analyst')
    e.add_merchant_member(owner, merchant['merchant_id'], support); e.add_merchant_member(owner, merchant['merchant_id'], analyst)
    pi=e.create_intent(owner, {'merchant_id':merchant['merchant_id'],'amount_minor':100,'currency':'CAD'}, 'rbac')
    with pytest.raises(Forbidden): e.authorize_and_post(support, pi['payment_intent_id'])
    e.authorize_and_post(owner, pi['payment_intent_id'])
    with pytest.raises(Forbidden): e.mark_pending_settlement(analyst, pi['payment_intent_id'])


def test_recon_break_freezes_payout_and_partner_rail():
    e=Engine(); owner, merchant=_owner_merchant(e,'recon')
    payable=_settled_payable(e, owner, merchant, 'before-break', 1500)
    admin=e._seed_user('admin','platform_admin')
    e.run_reconciliation(admin, 10, 0)
    with pytest.raises(KillSwitchActive): e.request_payout(owner, payable, 100, 'dest', 'after-break')
    pi=e.create_intent(owner, {'merchant_id':merchant['merchant_id'],'amount_minor':200,'currency':'CAD'}, 'pi-before-break') if False else None
    # partner rail itself must be frozen regardless of a new intent being blocked
    with pytest.raises(KillSwitchActive): e.partner_settle('sbx_pi_nonexistent')


def test_public_create_user_cannot_mint_privileged_roles():
    e=Engine()
    for role in ('platform_admin','system','partner_tech'):
        with pytest.raises(Forbidden): e.create_user('x-'+role, role)


def test_invoice_transition_requires_actor_and_rbac():
    e=Engine(); owner, merchant=_owner_merchant(e,'inv'); support=e.create_user('sup','support'); e.add_merchant_member(owner, merchant['merchant_id'], support)
    inv=e.create_invoice(owner, merchant['merchant_id'], 500, 'inv')
    with pytest.raises(Forbidden): e.transition_invoice(support, inv['invoice_id'], 'SENT')
    sent=e.transition_invoice(owner, inv['invoice_id'], 'SENT')
    assert sent['status']=='SENT'


def test_create_campaign_not_offered_when_donations_disabled():
    e=Engine(); owner,_=_owner_merchant(e,'camp')
    with pytest.raises(Unprocessable): e.create_campaign(owner,'Kitchen')


def test_feature_flag_rows_cannot_be_enabled(engine):
    import sqlite3
    with pytest.raises(sqlite3.IntegrityError):
        engine.conn.execute("UPDATE feature_flags SET enabled=1 WHERE flag='CARDS_EXECUTION'")


def test_duplicate_webhook_timestamp_is_rejected(engine, actors):
    from bfn_sandbox.crypto_webhooks import make_header
    pi=engine.create_intent(actors['owner'], {'merchant_id':actors['merchant']['merchant_id'],'amount_minor':100,'currency':'CAD'}, 'dup-ts')
    engine.authorize_and_post(actors['owner'], pi['payment_intent_id'])
    engine.mark_pending_settlement(actors['owner'], pi['payment_intent_id'])
    bundle=engine.mock_partner_emit('settled', pi['payment_intent_id'], 'sbx_dup_ts')
    good=make_header(engine.keys.active[1], bundle['raw'])
    tpart,vpart=good.split(',')
    with pytest.raises(Unprocessable, match='malformed signature'):
        engine.ingest_webhook(actors['partner'], bundle['raw'], f'{tpart},{tpart},{vpart}')


def test_webhook_requires_stored_partner_actor(engine, actors):
    from bfn_sandbox.crypto_webhooks import make_header
    pi=engine.create_intent(actors['owner'], {'merchant_id':actors['merchant']['merchant_id'],'amount_minor':100,'currency':'CAD'}, 'webhook-actor')
    bundle=engine.mock_partner_emit('settled', pi['payment_intent_id'], 'sbx_actor_guard')
    header=make_header(engine.keys.active[1], bundle['raw'])
    with pytest.raises(Forbidden):
        engine.ingest_webhook(actors['support'], bundle['raw'], header)


def test_unknown_sealed_flag_spelling_fails_closed():
    cfg=default_config(); cfg['cards_execution']='maybe'
    with pytest.raises(BootError): assert_boot_safe(cfg)

@pytest.mark.parametrize('value', ['2', 'enable', 'maybe', 'TRUE-ish', '-1'])
def test_live_money_env_unknown_or_truthy_spellings_fail_closed(monkeypatch, value):
    monkeypatch.setenv('LIVE_MONEY_ENABLED', value)
    with pytest.raises(BootError):
        assert_boot_safe(default_config())

@pytest.mark.parametrize('env_name', [
    'DONATIONS_ENABLED',
    'CROWDFUNDING_OFFERED',
    'CARDS_EXECUTION',
    'FX_EXECUTION',
    'REMITTANCE_EXECUTION',
    'KDN_PRODUCTION_WRITE',
])
def test_all_sealed_environment_overrides_fail_closed(monkeypatch, env_name):
    monkeypatch.setenv(env_name, 'true')
    with pytest.raises(BootError):
        assert_boot_safe(default_config())

@pytest.mark.parametrize('false_value', ['0', 'false', 'no', 'off', ''])
def test_sealed_environment_explicit_false_spellings_are_allowed(monkeypatch, false_value):
    monkeypatch.setenv('LIVE_MONEY_ENABLED', false_value)
    assert_boot_safe(default_config())


def test_nested_config_secret_is_rejected():
    cfg = default_config()
    cfg['webhook']['secret'] = 'sk_live_nested_bypass'
    with pytest.raises(BootError):
        assert_boot_safe(cfg)


def test_deeply_nested_list_secret_is_rejected():
    cfg = default_config()
    cfg['nested'] = {'items': [{'token': 'whsec_live_should_fail'}]}
    with pytest.raises(BootError):
        assert_boot_safe(cfg)
