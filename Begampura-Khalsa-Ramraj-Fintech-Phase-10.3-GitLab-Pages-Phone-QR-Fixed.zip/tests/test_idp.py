import pytest

from bfn_sandbox.errors import IdempotencyMismatch, Unprocessable


def test_t_idp_01_same_key_same_body_same_intent(engine, actors):
    body = {
        "merchant_id": actors["merchant"]["merchant_id"],
        "amount_minor": 2500,
        "currency": "CAD",
        "purpose": "merchant_sale",
    }
    a = engine.create_intent(actors["owner"], body, "order-1")
    b = engine.create_intent(actors["owner"], body, "order-1")
    assert a["payment_intent_id"] == b["payment_intent_id"]
    count = engine.conn.execute("SELECT COUNT(*) c FROM payment_intents").fetchone()["c"]
    assert count == 1


def test_t_idp_02_same_key_changed_amount_409(engine, actors):
    body = {
        "merchant_id": actors["merchant"]["merchant_id"],
        "amount_minor": 2500,
        "currency": "CAD",
        "purpose": "merchant_sale",
    }
    engine.create_intent(actors["owner"], body, "order-2")
    body2 = dict(body)
    body2["amount_minor"] = 2600
    with pytest.raises(IdempotencyMismatch) as exc:
        engine.create_intent(actors["owner"], body2, "order-2")
    assert exc.value.status_code == 409


def test_t_idp_03_same_raw_key_two_principals(engine, actors):
    body = {
        "merchant_id": actors["merchant"]["merchant_id"],
        "amount_minor": 1100,
        "currency": "CAD",
        "purpose": "merchant_sale",
    }
    a = engine.create_intent(actors["owner"], body, "shared-key")
    b = engine.create_intent(actors["finance"], body, "shared-key")
    assert a["payment_intent_id"] != b["payment_intent_id"]


def test_idempotency_key_required(engine, actors):
    body = {
        "merchant_id": actors["merchant"]["merchant_id"],
        "amount_minor": 500,
        "currency": "CAD",
    }
    with pytest.raises(Unprocessable):
        engine.create_intent(actors["owner"], body, "")
